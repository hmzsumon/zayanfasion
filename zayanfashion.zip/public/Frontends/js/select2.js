(function($) {
  'use strict';

  if ($(".searchjs").length) {
    $(".searchjs").select2();
  }

  if ($(".searchjs1").length) {
    $(".searchjs1").select2();
  }

  
  if ($(".searchjs2").length) {
    $(".searchjs2").select2();
  }

  if ($(".searchjs3").length) {
    $(".searchjs3").select2();
  }

  if ($(".searchjs4").length) {
    $(".searchjs4").select2();
  }

  if ($(".searchjs5").length) {
    $(".searchjs5").select2();
  }

  if ($(".js-example-basic-multiple").length) {
    $(".js-example-basic-multiple").select2();
  }
})(jQuery);