
<?php $__env->startSection('body'); ?>



<div class="col-md-12">
  <div class="container">
    <div class="row">

      <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col-3 d-none d-lg-block"> 
        <?php echo $__env->make('User.layouts.sidmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div><!----------End Sidebar-------->

      <?php if(count($searchproducts)>0): ?>
      <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 col-12 pb-5">


        <div class="col-md-12 mt-2 cathead">
          <strong>Search Products</strong>
        </div>

        <div class="col-md-12">
          <div class="scrolling-pagination">
            <div class="row">


              <?php if(isset($searchproducts)): ?>
              <?php $__currentLoopData = $searchproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php 
              $productname=str_replace(["%","/"," "],"-",$p->product_name)
              ?>

              <div class="col-xl-3 col-lg-3 col-md-3 col-sm-4 col-6 mt-4">
                <div class="bg-white product p-3">
                  <center>
                    <a href="<?php echo e(url('product')); ?>/<?php echo e($productname); ?>/<?php echo e($p->product_id); ?>"><img src="<?php echo e(asset('public/productImage')); ?>/<?php echo e($p->image); ?>" alt=""></a>
                    <div class="text-dark fw-bold productname mt-3"><?php echo e(substr($p->product_name, 0, 30)); ?><br>
                      <span>৳ <?php echo e(number_format($p->current_price, 2, '.', ',')); ?></span>
                      <?php if($p->discount_price > 0): ?>
                      <del>৳ <?php echo e(number_format($p->sale_price, 2, '.', ',')); ?></del>
                      <?php endif; ?>

                    </div>
                    <div class="mt-2"><button class="btn btn-success btn-sm" onclick="AddCart('<?php echo e($p->id); ?>')">Add To Cart</button></div>
                  </center>
                </div>
              </div>


              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>



              <?php echo e($searchproducts->links()); ?>


            </div>

          </div>
        </div>

      </div>

      <?php else: ?> 

      <div class="col-xl-9 col-lg-9 col-md-8 col-sm-12 col-12 pt-5">
        <div class="container padd">
          <center><img src="<?php echo e(asset('public/Frontend/img/no-order.svg')); ?>" class="img-fluid"><br>
            <strong class="text-dark">Product Not Found</strong>
          </center>

        </div>
      </div>


      <?php endif; ?>



      
    </div>
  </div>
</div>







<?php $__env->stopSection(); ?>





<?php echo $__env->make('User.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lifenatural/public_html/zayanfashion/resources/views/User/searchproducts.blade.php ENDPATH**/ ?>