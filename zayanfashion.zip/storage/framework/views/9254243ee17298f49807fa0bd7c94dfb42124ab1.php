<?php echo $__env->make('Admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<br>
<br>
<br>






<div class="main-content" style="overflow: hidden;">
            <!--page title start-->
            <div class="page-title" style="float: left;">
                <h4 class="mb-0">View Category
                    <small></small>
                </h4>
              
            </div>
            <div class="page-title" style="float: right; ">
                <a href="<?php echo e(route('category-add.create')); ?>" class="btn btn-outline-success">Add Category</a> 
                 <a href="<?php echo e(url('/Admin-dashboard')); ?>" class="btn btn-danger">X</a>
            </div>
            <!--page title end-->


            <div class="container" style="overflow-x: scroll;">

                <!-- state start-->
                <div class="row">
                    <div class=" col-sm-12">
                        <div class="mb-4">
                   
                            <div class="card-body">
                                <table id="example" class="display nowrap" style="width:100%">
                                    <thead>
                                    <tr>
                                        <th>SL</th>
                                        <th>Item Name</th>
                                        <th>Category Name</th>
                                        <th>Image</th>
                                        <th>Banner</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                 
                                    <tbody>

                                        <?php if(isset($data)): ?>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $showdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <tr id="tr-<?php echo e($showdata->id); ?>">
                                        <td><?php echo e($showdata->sl); ?></td>
                                        <td><?php echo e($showdata->item_name); ?></td>
                                        <td><?php echo e($showdata->category_name); ?></td>
                                        <td>
                                            <?php
                                             $path= base_path().'/public/categoryImage/'.$showdata->image;
                                            ?>

                                            <?php if($showdata->image): ?>
                                    <div uk-lightbox="animation: fade">
                                           <a href="<?php echo e(asset('/public/categoryImage')); ?>/<?php echo e($showdata->image); ?>"> <img src="<?php echo e(asset('/public/categoryImage')); ?>/<?php echo e($showdata->image); ?>" style="height: 50px"></a>
                                        </div>        

                                            <?php else: ?>
                                            <div uk-lightbox="animation: fade">
                                             <a href="<?php echo e(asset('/public')); ?>/noimage.png"> <img src="<?php echo e(asset('/public')); ?>/noimage.png" style="height: 50px"></a>
                                         </div>
                                         <?php endif; ?>


                                        </td>
                                        <td><img src="<?php echo e(asset('/public/categoryImage')); ?>/<?php echo e($showdata->banner); ?>" style="height: 50px"></td>
                                        <td>
                                            <a href="<?php echo e(route('category-add.edit',$showdata->id)); ?>" class="btn btn-outline-primary">Edit</a>
                                            <form method="POST" action="<?php echo e(route('category-add.destroy',$showdata->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo e(method_field('delete')); ?>

                                                <button type="submit" class="btn btn-outline-danger" onclick="return confirm('Are you sure?')">delete</button> 
                                            </form>
                                            
                                        </td>
                                    </tr>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                         <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>


                <!-- state end-->

            </div>
        </div>

<?php echo $__env->make('Admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script type="text/javascript">

</script><?php /**PATH /home/lifenatural/public_html/zayanfashion/resources/views/Admin/category/index.blade.php ENDPATH**/ ?>