<?php echo $__env->make('Admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<br>
<br>
<br>






<div class="main-content" style="overflow: hidden;">
            <!--page title start-->
            <div class="page-title" style="float: left;">
                <h4 class="mb-0">View Guest Registration
                    <small></small>
                </h4>
              
            </div>
            <div class="page-title" style="float: right;">
                <h4 class="mb-0"> <a href="<?php echo e(url('/Admin-dashboard')); ?>" class="btn btn-danger">X</a>
                    <small></small>
                </h4>
              
            </div>


            <div class="container" style="overflow-x: scroll;">

                <!-- state start-->
                <div class="row">
                    <div class=" col-sm-12">
                        <div class="mb-4">
                   
                            <div class="card-body">
                                <table id="example" class="display nowrap" style="width:100%">
                                    <thead>
                                    <tr>
                                        
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Vessel Name</th>
                                        <th>Rank</th>
                                        <th>Phone</th>
                                        
                                     
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                         
                                    <tbody>

                                        <?php if(isset($data)): ?>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $showdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <tr id="tr-<?php echo e($showdata->id); ?>">
                                        
                                        <td><?php echo e($showdata->id); ?></td>
                                        <td><?php echo e($showdata->first_name); ?>&nbsp;<?php echo e($showdata->last_name); ?></td>
                                        <td><?php echo e($showdata->vessel_name); ?></td>
                                        <td><?php echo e($showdata->rank); ?></td>
                                        <td><?php echo e($showdata->phone); ?></td>
                                      
                                        <td>
                                              <?php if($showdata->status == '1'): ?>
                                            <a href="<?php echo e(url('/inactiveguest')); ?>/<?php echo e($showdata->id); ?>" class="btn btn-success">Active</a>
                                            <?php else: ?>
                                            <a href="<?php echo e(url('/activeguest')); ?>/<?php echo e($showdata->id); ?>" class="btn btn-danger">Inactive</a>

                                            <?php endif; ?>

                                        </td>
                                        <td>
                                        
                                        <a href="<?php echo e(url('GuestListdelete',$showdata->id)); ?>" class="btn btn-outline-danger">delete</a>
                                     
                                            
                                        </td>
                                    </tr>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                         <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>


                <!-- state end-->

            </div>
        </div>

<?php echo $__env->make('Admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script type="text/javascript">

</script><?php /**PATH D:\xampp\htdocs\office\bdeshishop\resources\views/Admin/guest/index.blade.php ENDPATH**/ ?>