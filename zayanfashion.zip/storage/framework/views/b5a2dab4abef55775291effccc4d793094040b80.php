

<center>
  <div id="myBtns">
    <a href="#" class="text-danger" uk-toggle="target: #offcanvas-none">
        <br>
      <div><strong id="cartamount"></strong> Tk</div>
    </a>
  </div>
</center>



<style>

#myBtns {
  position: fixed; /* Fixed/sticky position */
  bottom: 300px; /* Place the button at the bottom of the page */
  right: 0px; /* Place the button 30px from the right */
  z-index: 99; /* Make sure it does not overlap */
  border: none; /* Remove borders */
  outline: none; /* Remove outline */
  color: red; /* Text color */
  cursor: pointer; /* Add a mouse pointer on hover */
  padding: 10px 20px; /* Some padding */
  font-size: 20px; /* Increase font size */
  font-weight: bold;
  transition: 0.5s;
  background: url("<?php echo e(asset('public/fontdev/dummy-cart.webp')); ?>");
  background-position:center;
  background-repeat:no-repeat;
  background-size:cover;
  border-radius: 5px 0px 0px 5px;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19); 
}

#myBtns:hover {
  opacity: 1;
  text-decoration: none;
}

.footermenu li {
    display: inline-block;
    padding-right: 10px;
    padding-left: 10px;
    border-right: 1px solid gray;

}

.footermenu li a {
    color: gray;
    font-size: 14px;
}


</style>





<?php  

    $setting = DB::table('settings')->first();
    
?>



<footer>
    <div class="footermenu">
        <div class="container">
            <div class="row">
                <div class="col-md-5 col-sm-4">
                    <!-- // -->
                    <div class="footer-logo">
                        <!-- <strong>POPULAR SEARCHES</strong><br><br> -->
                        <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('/public/siteImage')); ?>/<?php echo e($setting->logo); ?>" class="img-fluid"></a>
                        <p><?php echo e($setting->short_des ?? ''); ?></p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-4">
                    <strong class="text-white">Contact Us</strong><br><br>
                    <div class="footer-address">
                        <ul>
                            <li>
                                <div class="footer-address-icon">
                                    <i class="fas fa-map-marker-alt"></i>
                                </div>
                                <div class="footer-address-info">
                                    <p><?php echo e($setting->address ?? ''); ?></p>
                                </div>
                            </li>
                            <li>
                                <div class="footer-address-icon">
                                    <i class="fas fa-phone-volume"></i>
                                </div>
                                <div class="footer-address-info">
                                    <p><a class="text-white" href="tel:<?php echo e($setting->hotline); ?>"><?php echo e($setting->hotline); ?></a></p>
                                </div>
                            </li>
                            <li>
                                <div class="footer-address-icon">
                                    <i class="far fa-envelope"></i>
                                </div>
                                <div class="footer-address-info">
                                    <p><a class="text-white" href="mailto:<?php echo e($setting->email); ?>"><?php echo e($setting->email); ?></a></p>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="social-media">

                        <?php if($setting->facebook): ?>
                        <a href="<?php echo e($setting->facebook); ?>" target="_blank" class="social-media__item">
                            <div class="social-media__icon facebook"><i class="fab fa-facebook-f"></i></div>
                            <div class="social-media__text">Facebook</div>
                        </a>
                        <?php endif; ?>

                        <?php if($setting->twitter): ?>
                        <a href="<?php echo e($setting->twitter); ?>" target="_blank" class="social-media__item">
                            <div class="social-media__icon twitter"><i class="fab fa-twitter"></i></div>
                            <div class="social-media__text">Twitter</div>
                        </a>
                        <?php endif; ?>

                        <?php if($setting->instragram): ?>
                        <a href="<?php echo e($setting->instragram); ?>" target="_blank" class="social-media__item">
                            <div class="social-media__icon linkedin"><i class="fab fa-instagram"></i></div>
                            <div class="social-media__text">Instagram</div>
                        </a>
                        <?php endif; ?>

                        <?php if($setting->youtube): ?>
                        <a href="<?php echo e($setting->youtube); ?>" target="_blank" class="social-media__item">
                            <div class="social-media__icon youtube"><i class="fab fa-youtube"></i></div>
                            <div class="social-media__text">Youtube Channel</div>
                        </a>
                        <?php endif; ?>

                        <?php if($setting->email): ?>
                        <a href="<?php echo e($setting->email); ?>" target="_blank" class="social-media__item">
                            <div class="social-media__icon google"><i class="fas fa-envelope"></i></div>
                            <div class="social-media__text">Email</div>
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>


        <!-- foter change -->

        <!-- <?php if(isset($item)): ?>
        <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
        $item_name=str_replace(" ","-",$i->item_name)
        ?>

            <li><a href="<?php echo e(url('item')); ?>/<?php echo e($item_name); ?>/<?php echo e($i->id); ?>"><?php echo e($i->item_name); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?> -->

    </div>

    <!-- copyright -->
    <!-- <div class="text-light text-center py-4" style="background: #1e1e1e;">Copyright &copy 2021 Shopritefoodbd.com All Right Reserved <a href="https://branexit.com/" style="color: #F8432B;">Branexit</a></div> -->


</footer>



<div id="offcanvas-none" uk-offcanvas="mode: slide; overlay:true; flip: true;">

    <div class="uk-offcanvas-bar cartbackground">

        <div class="card">

            <div class="card-header bg-white">

                <div class="row">
                    <div class="col-md-6 col-6">
                        My Cart
                    </div>
                    <div class="col-md-6 col-6">
                        <span uk-icon="icon:close; ratio:1.2"
                        class="uk-offcanvas-close icone"></span>
                    </div>
                </div>

            </div>




            <div class="card-body p-0">

               <div id="cartshow"></div>







                <div class="card-footer mt-3" style="position: absolute; bottom: 0; width: 100%;">


                    <div class="row mt-2">
                        <div class="col-md-6 col-6">
                            Total
                        </div>

                        <div class="col-md-6 col-6 text-end">
                            ৳ <strong id="cartprice">0</strong>
                        </div>
                    </div>

                    <br>

                    <?php if(Auth('guest')->user()): ?>
                    <a href="<?php echo e(url('/Checkout')); ?>" class="btn btn-dark d-block"><i class="fa fa-shopping-basket" uk-tooltip="title: Remove; pos:bottom"></i>&nbsp;Checkout Order</a>
                    <?php else: ?>
                    <a href="<?php echo e(url('/user-login')); ?>" class="btn btn-dark d-block"><i class="fa fa-user" uk-tooltip="title: Remove; pos:bottom"></i>&nbsp;Login Account</a>   
                    <?php endif; ?>

                    <br><br>


                </div>

            </div>

        </div>

    </div>
</div>
</div><!----------End side Cart-------->




<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5eff60d26f9c1b7b"></script>

<script type="text/javascript" src="<?php echo e(asset('public/fontdev/')); ?>/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript" src="<?php echo e(asset('public/fontdev/')); ?>/js/uikit.min.js"></script>
<script type="text/javascript" src="<?php echo e(asset('public/fontdev/')); ?>/js/uikit-icons.min.js"></script>
<script type="text/javascript" src="<?php echo e(asset('public/assets/')); ?>/js/slick.min.js"></script>

<script src="<?php echo e(asset('public/assets/js/jquery.elevateZoom-3.0.8.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/fontdev/')); ?>/js/main.js"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jscroll/2.4.1/jquery.jscroll.min.js"></script>

<script type="text/javascript">
    $('ul.pagination').hide();
    $(function() {
        $('.scrolling-pagination').jscroll({
            loadingHtml: `<center><img class="mt-5" src="<?php echo e(asset('public/Frontend/img/loader.gif')); ?>" style="height:50px;"></center>`,
            autoTrigger: true,
            padding: 0,
            nextSelector: '.pagination li.active + li a',
            contentSelector: 'div.scrolling-pagination',
            callback: function() {
                $('ul.pagination').remove();
            }
        });
    });
</script>


<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<script>
    <?php if(Session::has('messege')): ?>

    var type="<?php echo e(Session::get('alert-type', 'info')); ?>"

    switch(type){

        case 'info':
        toastr.options.positionClass = 'toast-bottom-center';
        toastr.info("<?php echo e(Session::get('messege')); ?>");

        break;

        case 'success':
        toastr.options.positionClass = 'toast-bottom-center';
        toastr.success("<?php echo e(Session::get('messege')); ?>");

        break;

        case 'warning':
        toastr.options.positionClass = 'toast-bottom-center';
        toastr.warning("<?php echo e(Session::get('messege')); ?>");

        break;

        case 'error':
        toastr.options.positionClass = 'toast-bottom-center';
        toastr.error("<?php echo e(Session::get('messege')); ?>");

        break;

    }

    <?php endif; ?>

</script>


</body>
</html><?php /**PATH /home/lifenatural/public_html/bdeshishop/resources/views/User/layouts/footer.blade.php ENDPATH**/ ?>