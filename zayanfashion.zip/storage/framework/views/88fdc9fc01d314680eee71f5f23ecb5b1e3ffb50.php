<meta property="og:url" content="<?php echo e(Request::url()); ?>" />
<meta property="og:type" content="Article">
<meta property="og:title" content="<?php echo e($viewproduct->product_name); ?>">
<meta property="og:description" content="<?php echo e($viewproduct->product_name); ?>">
<meta property="og:image" content="<?php echo e(url('/public/productImage')); ?>/<?php echo e($viewproduct->image); ?>" />


<?php $__env->startSection('body'); ?>






<div class="col-md-12">
    <div class="container">
        <div class="row">

            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col-3 d-none d-lg-block">
                <?php echo $__env->make('User.layouts.sidmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!----------End Sidebar-------->

            <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 col-12 pb-5">
                <div class="col-md-12 mt-3 p-3 bg-white breadcumbs">
                    <li><a href="<?php echo e(url('/')); ?>"><i class="bi bi-house-fill"></i>&nbsp;&nbsp;Home</a></li>
                    <li><i class="bi bi-chevron-right"></i></li>
                    <li><?php echo e($viewproduct->product_name); ?></li>
                </div>


                <div class="col-md-12 mt-4 single bg-white rounded pb-4 p-3 p-lg-0">
                    <div class="row">
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 p-4">

                            <div class="simpleLens-gallery-container" id="demo-1">
                                <div class="simpleLens-container border" style="width: 100%;">
                                    <div class="simpleLens-big-image-container ">
                                        <a class="simpleLens-lens-image" data-lens-image="<?php echo e(asset('public/productImage')); ?>/<?php echo e($viewproduct->image); ?>">
                                            <img src="<?php echo e(asset('public/productImage')); ?>/<?php echo e($viewproduct->image); ?>" class="simpleLens-big-image p-2 product-image-zoom">
                                        </a>
                                    </div>
                                </div>

                                <div class="product-thumb-gallery">
                                    <div>
                                        <img src="<?php echo e(asset('public/productImage')); ?>/<?php echo e($viewproduct->image); ?>" alt="" width="100" height="100">


                                        <!-- <?php $__currentLoopData = $product_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <img src="<?php echo e(asset('/public/productImage')); ?>/<?php echo e($img->image); ?>" alt="" style="width: 9rem;">
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
                                    </div>
                                </div>
                            </div>
                        </div>



                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                            <br>
                            <strong><?php echo e($viewproduct->product_name); ?></strong><br>
                            <span><b>SKU:</b> <?php echo e($viewproduct->product_id); ?></span><br>
                            <?php if($viewproduct->stock_status == 1): ?>
                            <span class="bg-success text-light rounded" style="padding: 2px 10px; font-size: 13px;">Stock Available</span>
                            <?php else: ?>
                            <span class="bg-danger text-light rounded" style="padding: 2px 10px; font-size: 13px;">Stock Out</span>
                            <?php endif; ?>
                            <br><br>
                            <label>৳ <?php echo e(number_format($viewproduct->current_price, 2, '.', ',')); ?></label>

                            <?php if($viewproduct->discount_price > 0): ?>
                            <del>৳ <?php echo e(number_format($viewproduct->sale_price, 2, '.', ',')); ?></del>
                            <?php endif; ?>



                            <div class="quentity mt-3">
                                <label>Quentity</label><br>
                                <input type="number" min="<?php echo e($viewproduct->min_qunt); ?>" name="Quantity-<?php echo e($viewproduct->id); ?>" id="Quantity-<?php echo e($viewproduct->id); ?>" value="<?php echo e($viewproduct->min_qunt); ?>">
                            </div>

                            <div class="mt-4">
                                <div class="col-md-12">
                                    <?php if($viewproduct->stock_status == 1): ?>
                                    <button class="cart w-50" onclick="AddCart('<?php echo e($viewproduct->id); ?>')"><i class="fa fa-shopping-basket" aria-hidden="true"></i>&nbsp;&nbsp;Add To Cart</button>
                                    <?php else: ?>
                                    <button class="cart w-50" style="cursor: not-allowed;"><i class="fa fa-shopping-basket" aria-hidden="true"></i>&nbsp;&nbsp;Add To Cart</button>
                                    <?php endif; ?>
                                </div>
                            </div>


                            <div class="mt-4">
                                <span>Share With :</span><br>
                                <div class="addthis_inline_share_toolbox_0v9d"></div>

                            </div>


                        </div>



                    </div>
                </div>
                <!--------------End Product's--------------------->





                <div class="col-md-12 bg-white p-0 p-4 details mt-4">

                    <ul class="nav nav-tabs" id="myTab" role="tablist">

                        <li class="nav-item">

                            <a class="nav-link active" id="home-tab" data-toggle="tab" href="#Description" role="tab" aria-controls="home" aria-selected="true">Description</a>

                        </li>

                    </ul>



                    <div class="tab-content" id="myTabContent">

                        <div class="tab-pane fade show active mt-3" id="Description" role="tabpanel" aria-labelledby="home-tab">

                            <h4 class="font-weight-bold text-uppercase"><?php echo e($viewproduct->product_name); ?></h4>

                            <span>
                                <?php echo $viewproduct->product_details; ?>

                            </span>

                        </div>


                    </div>
                </div>



                <div class="col-md-12 mt-5 cathead">
                    <strong>Related Products</strong>
                    <div class="row">

                        <?php if(isset($related_product)): ?>
                        <?php $__currentLoopData = $related_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $productname = str_replace(['%', '/', ' '], '-', $r->product_name);
                        ?>



                        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-4 col-6 mt-4">
                            <div class="bg-white product p-3">
                                <center>
                                    <a href="<?php echo e(url('product')); ?>/<?php echo e($productname); ?>/<?php echo e($r->product_id); ?>"><img src="<?php echo e(asset('public/productImage')); ?>/<?php echo e($r->image); ?>" alt=""></a>
                                    <div class="text-dark fw-bold productname mt-3"><?php echo e($r->product_name); ?><br><span>৳ <?php echo e($r->current_price); ?></span></div>
                                    <div class="mt-2"><button class="btn btn-success btn-sm" onclick="AddCart('<?php echo e($r->id); ?>')">Add To Cart</button></div>
                                </center>
                            </div>
                        </div>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>






                    </div>
                </div>





            </div>


        </div>
    </div>
</div>









<?php $__env->stopSection(); ?>
<?php echo $__env->make('User.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lifenatural/public_html/zayanfashion/resources/views/User/single-product.blade.php ENDPATH**/ ?>