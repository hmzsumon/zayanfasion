
<?php $__env->startSection('body'); ?>


<?php

$activeslider = DB::table('sliders')->orderBy('id','DESC')->first();
$slidermore = DB::table('sliders')->orderBy('id','DESC')->skip(1)->limit(2)->get();

?>

<main>
    <div class="container">
        <div class="row">
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col-3 d-none d-lg-block">
                <?php echo $__env->make('User.layouts.sidmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!----------End Sidebar-------->

            <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 col-12">
                <div id="carouselExampleFade" class="carousel slide carousel-fade pt-2" data-bs-ride="carousel">
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <a href="<?php echo e($activeslider->url); ?>"><img class="d-block w-100 rounded" src="<?php echo e(asset('public/sliderImage')); ?>/<?php echo e($activeslider->image); ?>" id="sliderimage"></a>
                        </div>
                        <?php if(isset($slidermore)): ?>
                        <?php $__currentLoopData = $slidermore; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slidermoredata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="carousel-item">
                            <a href="<?php echo e($slidermoredata->url); ?>">
                                <img src="<?php echo e(asset('public/sliderImage')); ?>/<?php echo e($slidermoredata->image); ?>" class="d-block w-100 rounded banner-image">
                            </a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <section>
        <div class="container">

            <div class="head mb-4 mt-5">
                <strong>Browse all categories</strong>
            </div>

            <div class="uk-position-relative uk-visible-toggle w-100 uk-light bg-white p-4 rounded" tabindex="-1" uk-slider>
                <ul class="uk-slider-items uk-child-width-1-2 uk-child-width-1-6@m uk-grid">

                    <?php
                    $item = DB::table('product_item')->orderBy('sl','ASC')->get();
                    ?>

                    <?php if(isset($item)): ?>
                    <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $item_name=str_replace(" ","-",$i->item_name)
                    ?>
                    <li>
                        <div class="uk-panel">
                            <center>
                                <a href="<?php echo e(url('item')); ?>/<?php echo e($item_name); ?>/<?php echo e($i->id); ?>">
                                    <?php if($i->image == !NULL): ?>
                                    <img src="<?php echo e(asset('public/itemImage')); ?>/<?php echo e($i->image); ?>" class="img-fluid" style="height:50px;">
                                    <?php else: ?>
                                    <img src="<?php echo e(asset('public/fontdev/')); ?>/img/demo.jpg" class="img-fluid">
                                    <?php endif; ?>

                                
                                    <div class="text-dark fw-bold"><?php echo e($i->item_name); ?></div>
                                </a>
                            </center>
                        </div>
                    </li>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>


                </ul>

                <a class="uk-position-center-left uk-position-small bg-light text-dark rounded p-2" href="#" uk-slidenav-previous uk-slider-item="previous"></a>
                <a class="uk-position-center-right uk-position-small bg-light text-dark rounded p-2" href="#" uk-slidenav-next uk-slider-item="next"></a>

            </div>

            <?php
            $offerbanner = DB::table('explore_banners')->limit(4)->get();
            ?>

            <div class="col-md-12 mt-4">
                <div class="row">

                    <?php if(isset($offerbanner)): ?>
                    <?php $__currentLoopData = $offerbanner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col-3">
                        <a href="<?php echo e($offer->url); ?>"><img src="<?php echo e(asset('public/exploreImage')); ?>/<?php echo e($offer->image); ?>" class="img-fluid"></a>
                    </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                </div>
            </div>
            <!---------End Offer Banner--------->
            <?php
            $itemcat = DB::table('product_item')->orderBy('sl','ASC')->limit(5)->get();
            ?>

            <?php if(isset($itemcat)): ?>
            <?php $__currentLoopData = $itemcat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemcats): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $item_name=str_replace(" ","-",$itemcats->item_name);
            $product = DB::table('product_productinfo')->where('item_id',$itemcats->id)->where('status',1)->orderBy('id','DESC')->limit(12)->get();
            ?>

            <?php if(count($product)>0): ?>
            <div class="col-md-12 mt-5">
                <div class="head">
                    <!-- dynamic: <?php echo e($itemcats->item_name); ?> -->
                    <strong><?php echo e($itemcats->item_name); ?></strong>
                    <a href="<?php echo e(url('item')); ?>/<?php echo e($item_name); ?>/<?php echo e($itemcats->id); ?>" class="float-end button">View All</a>
                </div>

                <div class="uk-position-relative uk-visible-toggle w-100 py-3 rounded" tabindex="-1" uk-slider>
                    <div class="row">
                        <?php if(isset($product)): ?>
                        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($p->item_id == $itemcats->id): ?>
                        <?php
                        $productname=str_replace(["%","/"," "],"-",$p->product_name)
                        ?>

                        <div class="col-6 col-md-4 col-lg-2 mb-3">
                            <div class="uk-panel">
                                <a href="<?php echo e(url('product')); ?>/<?php echo e($productname); ?>/<?php echo e($p->product_id); ?>" class="text-dark">
                                    <img src="<?php echo e(asset('public/productImage')); ?>/<?php echo e($p->image); ?>" alt="" style="width: 100%;margin: auto;display: block;margin-bottom: 10px;">


                                    <div class="fw-bold">
                                    <?php echo e(substr($p->product_name, 0, 20)); ?>

                                    </div>
                                    <div>৳ <?php echo e(number_format($p->current_price, 2, '.', ',')); ?></div>
                                    <?php if($p->discount_price > 0): ?>
                                    <del>৳ <?php echo e(number_format($p->sale_price, 2, '.', ',')); ?></del>
                                    <?php endif; ?>
                                </a>
                                <!-- <div class="">
                                        <button class="btn btn-sm" onclick="AddCart('<?php echo e($p->id); ?>')">Add To Cart</button>
                                    </div> -->
                            </div>
                        </div>

                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>



                    </div>

                    <a class="uk-position-center-left uk-position-small bg-light text-dark rounded p-2" href="#" uk-slidenav-previous uk-slider-item="previous"></a>
                    <a class="uk-position-center-right uk-position-small bg-light text-dark rounded p-2" href="#" uk-slidenav-next uk-slider-item="next"></a>

                </div>


            </div>
            <!------------End Popular Products---------->

            <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </section>
</main>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('User.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lifenatural/public_html/bdeshishop/resources/views/User/layouts/home.blade.php ENDPATH**/ ?>