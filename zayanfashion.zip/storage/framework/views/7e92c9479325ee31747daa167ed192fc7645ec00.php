
<?php $__env->startSection('body'); ?>


<div class="col-md-12">
  <div class="container">
    <div class="row">

      <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col-3 d-none d-lg-block"> 
        <?php echo $__env->make('User.layouts.sidmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div><!----------End Sidebar-------->

      <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 col-12 pb-5">
        <div class="col-lg-6 offset-lg-3 col-md-10 offset-md-1 col-sm-10 offset-sm-1 col-12 pt-5 mt-4">
          <div class="col-md-12 p-4 pb-5 formback">
            <center><strong>Login</strong><br><span>Login your account Thank You !!</span></center>
            <hr>

            <form method="post" action="<?php echo e(url('/guest-login')); ?>">
              <?php echo csrf_field(); ?>
              <div class="form-group col-md-12 mb-3">
                <label>Mobile</label>
                <input type="text" class="form-control textfill" name="email" placeholder="Mobile" required="" <?php if(Cookie::has('user')): ?> value="<?php echo e(Cookie::get('user')); ?>" <?php endif; ?>>
              </div>

              <div class="form-group col-md-12 mb-3">
                <label>Password</label>
                <input type="Password" class="form-control textfill" name="password" placeholder="Password" required="" <?php if(Cookie::has('password')): ?> value="<?php echo e(Cookie::get('password')); ?>" <?php endif; ?>>
              </div>

              <div class="col-md-12 mt-2 mb-3">
                <button class="btn btn-success d-block w-100 p-2">LOGIN</button>
              </div>
            </form>

            <br>
            <center>
              <span>Don't have an account? <a href="<?php echo e(url('/user-Register')); ?>" class="text-success">Register</a></span><br>
              <a href="<?php echo e(url('/forgot_password')); ?>" class="text-warning">Forget Password</a>
            </center>



          </div>
        </div>



      </div>

      
    </div>
  </div>
</div>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('User.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lifenatural/public_html/bdeshishop/resources/views/User/Guest/signin.blade.php ENDPATH**/ ?>