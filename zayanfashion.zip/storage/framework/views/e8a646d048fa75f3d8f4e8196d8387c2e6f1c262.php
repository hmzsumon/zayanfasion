<?php echo $__env->make('Admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>

<div class="main-content">

    <div class="container">



        <br>

        <br>

        <br>

        <br>

        <?php if($errors->any()): ?>

        <div class="alert alert-danger">

            <ul>

                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <li><?php echo e($error); ?></li>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ul>

        </div>

        <?php endif; ?>

        <div class="row">

            <div class="col-md-12">



                <div class="card card-shadow mb-4">

                    <div class="card-header">

                        <div class="card-title" style="float: left;">

                            Create Product

                        </div>

                        <div class="card-title" style="float: right;">

                            <a href="<?php echo e(route('product-add.index')); ?>" class="btn btn-warning">View</a>

                            <a href="<?php echo e(url('/Admin-dashboard')); ?>" class="btn btn-danger">X</a>

                        </div>

                    </div>

                    <div class="card-body">

                        <form method="post" action="<?php echo e(route('product-add.store')); ?>" name="basic_validate"
                        novalidate="novalidate" enctype="multipart/form-data">

                        <?php echo csrf_field(); ?>

                        <div class="row">

                            <div class="col-md-6">

                                <div class="control-group mb-3">

                                    <label class="control-label">Product Code</label>

                                    <div class="controls">

                                        <input type="text" name="product_id" id="product_id" class="form-control"
                                        placeholder="SMBP01" 
                                        value="<?php echo e(old('product_id')); ?>" />

                                    </div>

                                </div>

                                <div class="control-group mb-3">

                                    <label class="control-label">Item Name</label>

                                    <div class="controls">

                                        <select name="item_id" onchange="GetCategory();" id="item_id"
                                        class="form-control searchjs">

                                        <option value="">Select An Item</option>

                                        <?php if(count($iteminfo)): ?>

                                        <?php $__currentLoopData = $iteminfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->item_name); ?>

                                        </option>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php endif; ?>



                                    </select>

                                </div>

                            </div>





                            <div class="control-group mb-3">

                                <label class="control-label">Category Name</label>

                                <div class="controls">

                                    <select name="category_id" id="category_id" onchange="getsubcat();"
                                    class="form-control searchjs1">

                                    <option value=""> Select A Category</option>

                                </select>

                            </div>

                        </div>








                        <div class="control-group mb-3">

                            <label class="control-label">Brand Name</label>

                            <div class="controls">

                                <select name="brand_id" id="brand_id" class="form-control searchjs3">

                                    <option value=""> Select A Brand</option>

                                    <?php if(isset($company) && count($company)): ?>

                                    <?php $__currentLoopData = $company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $com): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <option value="<?php echo e($com->id); ?>"><?php echo e($com->company_name); ?>

                                    </option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php endif; ?>

                                </select>

                            </div>

                        </div>






                        <div class="control-group mb-3">

                            <label class="control-label">Product Name:</label>

                            <div class="controls">

                                <input type="text" name="product_name" id="product_name"
                                class="form-control" placeholder="Product Name (English)"
                                value="<?php echo e(old('product_name')); ?>" />

                            </div>

                        </div>




                        <div class="control-group mb-3">

                            <label class="control-label">Min. Quntity</label>

                            <div class="controls">

                                <input type="number" min="1" name="min_qunt" id="min_qunt" class="form-control"
                                placeholder="ex:2" 
                                value="<?php echo e(old('min_qunt')); ?>" />

                            </div>

                        </div>



                        <div class="control-group mb-3">

                            <label class="control-label">Measurement Type:</label>

                            <div class="controls">

                                <select class="form-control searchjs5" name="measurement_type"
                                id="measurement_type">

                                <?php if($measurementinfo): ?>

                                <?php $__currentLoopData = $measurementinfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $measurement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option value="<?php echo e($measurement->id); ?>">
                                    <?php echo e($measurement->measurement_type); ?></option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php endif; ?>

                                </select>

                            </div>

                        </div>







                        <div class="control-group mb-3">

                            <label class="control-label">Purchase Price:</label>

                            <div class="controls">

                                <input type="number" name="purchase_price" id="purchase_price"
                                class="form-control" placeholder="Purchase Price" 
                                value="0" />

                            </div>

                        </div>






                        <div class="control-group mb-3">

                            <label class="control-label">Sale Price</label>

                            <div class="controls">

                                <input type="number" name="sale_price" id="sale_price" class="form-control"
                                class="form-control" placeholder="Sale Price" 
                                value="<?php echo e(old('sale_price')); ?>" onkeyup="calculate()" min="1" />

                            </div>

                        </div>



                        <div class="control-group mb-3">

                            <label class="control-label">Discount Amount</label>

                            <div class="controls">

                                <input type="number" name="discount_price" id="discount_price"
                                class="form-control" class="form-control" placeholder="Discount Amount"
                                value="0" onkeyup="calculate()" min="1" />

                            </div>

                        </div>





                        <div class="control-group mb-3">

                            <label class="control-label">Discount percentage</label>

                            <div class="controls">

                                <input type="text" name="discount_per" id="discount_per"
                                class="form-control" class="form-control"
                                placeholder="Discount percentage" 
                                value="<?php echo e(old('discount_per')); ?>" min="0" readonly="" />

                            </div>

                        </div>



                        <div class="control-group mb-3">

                            <label class="control-label">Current Price</label>

                            <div class="controls">

                                <input type="number" name="current_price" id="current_price"
                                class="form-control" class="form-control" placeholder="Cuurent Price"
                                value="<?php echo e(old('current_price')); ?>" />

                            </div>

                        </div>










                    </div>



                    <div class="col-md-6">




                        <div class="control-group mb-3">
                            <label class="control-label">Short Description</label>



                            <div class="controls">

                                <textarea name="product_us" id="product_us" class="form-control"
                                style="resize: none;"><?php echo e(old('product_us')); ?></textarea>

                            </div>

                        </div>



                        <div class="control-group mb-3">



                            <label class="control-label">Product Details </label>



                            <div class="controls">

                                <textarea name="product_details" id="product_details" class="form-control"
                                style="resize: none;"><?php echo e(old('product_details')); ?></textarea>

                            </div>

                        </div>



                        <div class="control-group mb-3">

                            <label class="control-label">Stock Available/Out</label>



                            <div class="controls">

                                <select name="stock_status" id="stock_status" class="form-control">



                                    <option value="1">Stock Available</option>

                                    <option value="0">Stock Out</option>

                                </select>

                            </div>

                        </div>




                        <div class="control-group mb-3">



                            <label class="control-label">Shipping Class</label>



                            <div class="controls">

                                <select name="shipping_id" id="shipping_id" class="form-control" required="">



                                    <option value="">Select One</option>

                                    <?php if($shipping): ?>

                                    <?php $__currentLoopData = $shipping; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <option value="<?php echo e($ship->id); ?>">
                                        <?php echo e($ship->shipping_name); ?>

                                    </option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php endif; ?>

                                </select>

                            </div>

                        </div>



                        <div class="control-group mb-3">



                            <label class="control-label">Product Image:</label>



                            <div class="controls">

                                <input type="file" name="image[]" id="image" multiple>

                            </div>

                        </div>





                        <div class="control-group mb-3">



                            <label class="control-label text-danger"><b>Offer Select</b></label>



                            <div class="controls">

                                <select name="offer_id" id="offer_id" class="form-control">
                                    <option value="">Select Offer</option>
                                    <option value="1">Huge Savings</option>
                                    <option value="2">Order More Save more</option>
                                    <option value="3">Discount Offer</option>
                                    <option value="4">Buy one get 1 free</option>
                                    <option value="5">Special Services</option>

                                </select>

                            </div>

                        </div>








                    </div>

                </div>

                <br>

                <div align="center">

                    <input type="submit" name="submit" class="btn btn-success">

                </div>

            </form>

        </div>

    </div>









</div>

</div>

</div>

</div>

<?php echo $__env->make('Admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<!--<script src="<?php echo e(URL::to('/')); ?>/public/editor3/ckeditor.js"></script> -->



<link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.css" rel="stylesheet">

<script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.js"></script>



<script>
    $('#product_us').summernote({
        toolbar: [
            // [groupName, [list of button]]
            ['style', ['bold', 'italic', 'underline', 'clear']],
            ['font', ['strikethrough', 'superscript', 'subscript']],
            ['fontsize', ['fontsize']],
            ['fontname', ['fontname']],
            ['color', ['color']],
            ['para', ['ul', 'ol', 'paragraph']],
            ['height', ['height']],
            ['table', ['table']],
            ['insert', ['link', 'picture', 'video']],
            ['view', ['fullscreen', 'codeview', 'help']],
            ]
        });

    $('#product_details').summernote({
        toolbar: [
            // [groupName, [list of button]]
            ['style', ['bold', 'italic', 'underline', 'clear']],
            ['font', ['strikethrough', 'superscript', 'subscript']],
            ['fontsize', ['fontsize']],
            ['fontname', ['fontname']],
            ['color', ['color']],
            ['para', ['ul', 'ol', 'paragraph']],
            ['height', ['height']],
            ['table', ['table']],
            ['insert', ['link', 'picture', 'video']],
            ['view', ['fullscreen', 'codeview', 'help']],
            ]
        });

    $('#condition').summernote({
        toolbar: [
            // [groupName, [list of button]]
            ['style', ['bold', 'italic', 'underline', 'clear']],
            ['font', ['strikethrough', 'superscript', 'subscript']],
            ['fontsize', ['fontsize']],
            ['fontname', ['fontname']],
            ['color', ['color']],
            ['para', ['ul', 'ol', 'paragraph']],
            ['height', ['height']],
            ['table', ['table']],
            ['insert', ['link', 'picture', 'video']],
            ['view', ['fullscreen', 'codeview', 'help']],
            ]
        });

    </script>

    <script type="text/javascript">
        function calculate()

        {



            var sale_price = $("#sale_price").val();

            var discount_price = $("#discount_price").val();

            var total = 0;





            total = sale_price - discount_price;

            per = (discount_price / sale_price * 100);



            $("#current_price").val(total);

            $("#discount_per").val(per.toFixed(0));



        }





        function GetCategory() {

            var item_id = $('#item_id').val();

            if (item_id != 0) {

                $.ajax({

                    headers: {
                        'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
                    },

                    url: '<?php echo e(url('CreateProductGetCategory')); ?>',

                    type: 'POST',

                    data: {
                        id: item_id
                    },

                    success: function(data) {

                        $('#category_id').html(data);

                    //GetBrand(); 

                }

            });

            } else {

                $('#category_id').html('<option value="0">Select A Category</option>');

            }

        }



        function getsubcat() {

            var category_id = $('#category_id').val();

            if (category_id != 0) {

                $.ajax({

                    headers: {
                        'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
                    },

                    url: '<?php echo e(url('CreateProductGetsubCategory')); ?>',

                    type: 'POST',

                    data: {
                        id: category_id
                    },

                    success: function(data) {

                        $('#subcategory_id').html(data);

                    //GetBrand(); 

                }

            });

            } else {

                $('#subcategory_id').html('<option value="0">Select A subCategory</option>');

            }

        }









        function Add_Product() {

            var formData = new FormData();

            formData.append('img', $('#img')[0].files[0]);

            formData.append('img2', $('#img2')[0].files[0]);

            formData.append('img3', $('#img3')[0].files[0]);

            formData.append('product_id', $("#product_id").val());

            formData.append('product_name', $("#product_name").val());

            formData.append('product_name_bangla', $("#product_name_bangla").val());

            formData.append('item_id', $("#item_id").val());

            formData.append('category_id', $("#category_id").val());

            formData.append('brand_id', $("#brand_id").val());

            formData.append('measurement_unit_id', $("#measurement_unit_id").val());

            formData.append('purchase_price', $("#purchase_price").val());

            formData.append('sale_price', $("#sale_price").val());

            formData.append('old_price', $("#old_price").val());

            formData.append('product_details', $("#editor1").val());

            formData.append('barcode', $("#barcode").val());

            formData.append('pro_qunt', $("#pro_qunt").val());

            formData.append('stock', $("#stock").val());

            formData.append('why_is', $("#why_is").val());

            formData.append('shelf_no', $("#shelf_no").val());

            $.ajax({

                headers: {
                    'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
                },

                url: '<?php echo e(URl::to('CreateProduct')); ?>',

                type: 'POST',

                processData: false,

                contentType: false,

                data: formData,

                success: function(data) {

                    data = data.split('///');

                    if (data[0] == "yes") {

                        $('#error').hide();

                        $('#success').html(data[1]);

                        $('#success').show();

                        $('#product_name').val('');

                        $('#product_name_bangla').val('');

                        $('#purchase_price').val('');

                        $('#sale_price').val('');

                        $('#old_price').val('');

                        $('#editor1').val('');

                        $('#why_is').val('');

                        $('#shelf_no').val('');

                        $('#pro_qunt').val('');

                        $('#barcode').val('');

                    }



                    if (data[0] == "no") {

                        $('#success').hide();

                        $('#error').html(data[1]);

                        $('#error').show();

                    }



                }

            });



        }



        $(function() {

            $('#staticParent').on('keydown', '#child', function(e) {
                -1 !== $.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) || /65|67|86|88/.test(e
                    .keyCode) && (!0 === e.ctrlKey || !0 === e.metaKey) || 35 <= e.keyCode && 40 >= e
                .keyCode || (e.shiftKey || 48 > e.keyCode || 57 < e.keyCode) && (96 > e.keyCode || 105 <
                    e.keyCode) && e.preventDefault()
            });

        })



        Dropzone.options.dropzoneForm = {

            autoProcessQueue: false,

            acceptedFiles: ".png,.jpg,.gif,.bmp,.jpeg",



            init: function() {

                var submitButton = document.querySelector("#submit-all");

                myDropzone = this;



                submitButton.addEventListener('click', function() {

                    myDropzone.processQueue();

                });



                this.on("complete", function() {

                    if (this.getQueuedFiles().length == 0 && this.getUploadingFiles().length == 0)

                    {

                        var _this = this;

                        _this.removeAllFiles();

                    }

                    load_images();

                });



            }



        };

    </script>
<?php /**PATH /home/lifenatural/public_html/bdeshishop/resources/views/Admin/product/create.blade.php ENDPATH**/ ?>