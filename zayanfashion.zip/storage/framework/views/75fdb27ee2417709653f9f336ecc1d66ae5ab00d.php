<?php echo $__env->make('Admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<div class="main-content">
    <div class="container">

<br>
<br>
<br>
<br>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
          <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
        <?php endif; ?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card card-shadow mb-4">
                            <div class="card-header">
                                <div class="card-title" style="float: left;">
                                    Setting Update
                                </div> 
                        
                            </div>
                            <div class="card-body">
                                <form id="" method="post" class=" right-text-label-form feedback-icon-form" action="<?php echo e(url('updatesetting/'. $view->id)); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                       

                                
                                    <div class="form-group row">
                                        <label class="col-sm-4 control-label" for="username1">Title</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control"  name="title" placeholder="Title"  value="<?php echo e($view->title); ?>">
                                        </div>
                                    </div>
                                
                                    <div class="form-group row">
                                        <label class="col-sm-4 control-label" for="username1">Address</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control"  name="address" placeholder="Address"  value="<?php echo e($view->address ?? ''); ?>">
                                        </div>
                                    </div>
                                
                                    <div class="form-group row">
                                        <label class="col-sm-4 control-label" for="username1">Short Description</label>
                                        <div class="col-sm-6">
                                            <textarea name="short_des" class="form-control" minlength="100" rows="3"><?php echo e($view->short_des ?? ''); ?></textarea>
                                        </div>
                                    </div>
                                    
                                      <div class="form-group row">
                                        <label class="col-sm-4 control-label" for="username1">Hotline</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control"  name="hotline" placeholder="Hotline"  value="<?php echo e($view->hotline); ?>">
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label class="col-sm-4 control-label" for="username1">Email</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control"  name="email" placeholder="Email"  value="<?php echo e($view->email); ?>">
                                        </div>
                                    </div>


                                      <div class="form-group row">
                                        <label class="col-sm-4 control-label" for="username1">Facebook</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control"  name="facebook" placeholder="Facebook"  value="<?php echo e($view->facebook); ?>">
                                        </div>
                                    </div>
                                    
                                    
                                      <div class="form-group row">
                                        <label class="col-sm-4 control-label" for="username1">Twitter</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control"  name="twitter" placeholder="Twitter"  value="<?php echo e($view->twitter); ?>">
                                        </div>
                                    </div>


                                    <div class="form-group row">
                                        <label class="col-sm-4 control-label" for="username1">Instragram</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control"  name="instragram" placeholder="Instragram"  value="<?php echo e($view->instragram); ?>">
                                        </div>
                                    </div>



                                    <div class="form-group row">
                                        <label class="col-sm-4 control-label" for="username1">Youtube</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control"  name="youtube" placeholder="Youtube"  value="<?php echo e($view->youtube); ?>">
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label class="col-sm-4 control-label" for="username1">Logo</label>
                                        <div class="col-sm-6">
                                            <?php
                                             $path= base_path().'/public/categoryImage/'.$view->logo;
                                            ?>
                                            <?php if($view->logo): ?>
                                            <img src="<?php echo e(asset('/public/siteImage')); ?>/<?php echo e($view->logo); ?>" alt="">
                                            <?php endif; ?>

                                            <input type="file" class="form-control"  name="logo">
                                            <span>Size: 224*50px</span>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label class="col-sm-4 control-label" for="username1">Favicon</label>
                                        <div class="col-sm-6">
                                            <?php
                                             $path= base_path().'/public/categoryImage/'.$view->favicon;
                                            ?>
                                            <?php if($view->favicon): ?>
                                            <img src="<?php echo e(asset('/public/siteImage')); ?>/<?php echo e($view->favicon); ?>" alt="">
                                            <?php endif; ?>

                                            <input type="file" class="form-control"  name="favicon">
                                            <span>Size: 16*16px</span>
                                        </div>
                                    </div>
                                    
                                    <h3>API</h3><hr>
                                    
                                        <div class="form-group row">
                                        <label class="col-sm-4 control-label" for="username1">API url</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control"  name="api_url"  value="<?php echo e($view->api_url); ?>">
                                        </div>
                                    </div>



                                    <div class="form-group row">
                                        <label class="col-sm-4 control-label" for="username1">API Key</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control"  name="api_key"  value="<?php echo e($view->api_key); ?>">
                                        </div>
                                    </div>



                                    <div class="form-group row">
                                        <label class="col-sm-4 control-label" for="username1">Sender ID</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control"  name="senderid"  value="<?php echo e($view->senderid); ?>">
                                        </div>
                                    </div>




                                    <div class="form-group row">
                                        <div class="col-sm-8 ml-auto">
                                            <button type="submit" class="btn btn-success" name="signup1" value="Sign up">Update</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>







    </div>
</div>








<?php echo $__env->make('Admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script type="text/javascript">
      function check_all()
      {
      
      if($('#chkbx_all').is(':checked')){
        $('input.check_elmnt2').prop('disabled', false);
        $('input.check_elmnt').prop('checked', true);
        $('input.check_elmnt2').prop('checked', true);
      }else{
        $('input.check_elmnt2').prop('disabled', true);
        $('input.check_elmnt').prop('checked', false);
        $('input.check_elmnt2').prop('checked', false);
        }
    } 
    

    function chekMain(getID){
       
          if($('#linkID-'+getID).is(':checked')){
              
            $("input#sublinkID-"+getID).attr('disabled', false);
            $("input#sublinkID-"+getID).attr('checked', true);
          
          }else{
            $("input#sublinkID-"+getID).attr('disabled', true);
            $("input#sublinkID-"+getID).attr('checked', false);
          
          }
      
        }


</script><?php /**PATH D:\xampp\htdocs\office\bdeshishop\resources\views/Admin/other/settings.blade.php ENDPATH**/ ?>