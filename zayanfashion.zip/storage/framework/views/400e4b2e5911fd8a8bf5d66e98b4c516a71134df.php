<?php echo $__env->make('Admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<br>
<br>
<br>






<div class="main-content" style="overflow: hidden;">
     <?php echo $__env->make('Admin.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!--page title start-->
            <div class="page-title" style="float: left;">
                <h4 class="mb-0">View Pending Order
                    <small></small>
                </h4>
              
            </div>
            
            
            <div class="page-title" style="float: right; ">
                <a href="<?php echo e(url('ProcessOrder')); ?>" class="btn btn-outline-info btn-sm">Process</a> 
            </div>   

            <div class="page-title" style="float: right; ">
                <a href="<?php echo e(url('Shipping-Order')); ?>" class="btn btn-outline-info btn-sm">Shipping</a> 
            </div>   

            <div class="page-title" style="float: right; ">
                <a href="<?php echo e(url('onthewayOrder')); ?>" class="btn btn-outline-primary btn-sm">On the Way</a> 
            </div>


            <div class="page-title" style="float: right; ">
                <a href="<?php echo e(url('CompleteOrder')); ?>" class="btn btn-outline-success btn-sm">Complete</a> 
            </div>

            <div class="page-title" style="float: right; ">
                <a href="<?php echo e(url('RejectOrder')); ?>" class="btn btn-outline-danger btn-sm">Reject</a> 
            </div>
             <div class="page-title" style="float: right; ">
                 <a href="<?php echo e(url('/Admin-dashboard')); ?>" class="btn btn-outline-danger btn-sm">X</a>
            </div>
            <!--page title end-->


            <div class="container" style="overflow-x: scroll; max-height:726px">

                <!-- state start-->
                <div class="row">
                    <div class=" col-sm-12">
                        <div class="mb-4">
                   
                                    <span id="sms"></span>
                            <div class="card-body">
                                <table id="example" class="display nowrap" style="width:100%;text-align:center;">
                                    <thead>
                                    <tr>
                                       <th>SL</th>
                                        <th>Order ID</th>
                                        <th>Date</th>
                                        <th>Bill To Name</th>
                                        <th>Ship To Name</th>
                                        <th>Vessel</th>
                                        <th>Rank</th>
                                        <th>Billing Phone</th>
                                        <th>Shipping Phone</th>
                                        <th>Shipping Area</th>
                                        <th>Payment Method</th>
                                        <th>Payment Account</th>
                                        <th>Transaction ID</th>
                                     
                                        <th>SKU</th>
                                        <th>Unit Price</th>
                                        <th>Discount Percentage</th>
                                        <th>Discount Amount</th>
                                        <th>Discounted Price</th>
                                        <th>Quantity</th>
                                        <th>Delivery Charge</th>
                                        <th>Discount</th>
                                        <th>Sub Total</th>
                                        <th>Grand Total</th>
                                        <th>Note</th>
                                        <th>Reject Note</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tfoot>
                                    <tr>
                                       <th>SL</th>
                                        <th>Order ID</th>
                                        <th>Date</th>
                                        <th>Bill To Name</th>
                                        <th>Ship To Name</th>
                                        <th>Vessel</th>
                                        <th>Rank</th>
                                        <th>Billing Phone</th>
                                        <th>Shipping Phone</th>
                                        <th>Shipping Area</th>
                                        <th>Payment Method</th>
                                        <th>Payment Account</th>
                                        <th>Transaction ID</th>
                                       
                                        <th>SKU</th>
                                        <th>Unit Price</th>
                                        <th>Discount Percentage</th>
                                        <th>Discount Amount</th>
                                        <th>Discounted Price</th>
                                        <th>Quantity</th>
                                        <th>Delivery Charge</th>
                                        <th>Discount</th>
                                        <th>Sub Total</th>
                                        <th>Grand Total</th>
                                        <th>Note</th>
                                        <th>Reject Note</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php
                                        $sl=1;
                                        ?>
                                        <?php if(isset($data)): ?>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $showdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <?php
                                        
                                        $product = DB::table('invoices')
                    	            ->join('shopping_carts','shopping_carts.session_id','invoices.session_id')
                                    ->join('product_productinfo','product_productinfo.id','shopping_carts.product_id')
                                    ->select('product_productinfo.product_name','product_productinfo.current_price',
                                    'product_productinfo.product_id','invoices.invoice_id','shopping_carts.quantity','shopping_carts.discount_price as dp',
                                    'shopping_carts.sale_price as sp','shopping_carts.current_price as cp')
                                    ->where('invoices.invoice_id',$showdata->invoice_id)
                                    ->get();
                                        ?>
                                      <tr id="tr-<?php echo e($showdata->invoice_id); ?>">

                                        <td data-toggle="tooltip" title="SL"><?php echo e($sl++); ?></td>
                                        <td data-toggle="tooltip" title="Order ID"><?php echo e($showdata->invoice_id); ?></td>
                                        <td data-toggle="tooltip" title="Date"><?php echo e($showdata->created_at); ?></td>
                                        <td data-toggle="tooltip" title="Bill To Name"><?php echo e($showdata->billing_name); ?></td>
                                        <td data-toggle="tooltip" title="Ship To Name"><?php echo e($showdata->first_name); ?>&nbsp;<?php echo e($showdata->last_name); ?></td>
                                        <td data-toggle="tooltip" title="Billing address"><?php echo e($showdata->vessel_name); ?></td>
                                        <td data-toggle="tooltip" title="shipping address"><?php echo e($showdata->rank); ?></td>
                                        <td data-toggle="tooltip" title="Billing Phone"><?php echo e($showdata->billing_phone); ?></td>
                                        <td data-toggle="tooltip" title="Shipping Phone"><?php echo e($showdata->phone); ?></td>
                                        <td data-toggle="tooltip" title="Shipping Area"><?php echo e($showdata->district_name); ?>,<?php echo e($showdata->thana_name); ?></td>
                                        <td data-toggle="tooltip" title="Payment Method"><?php echo e($showdata->payment_type); ?></td>
                                        <td data-toggle="tooltip" title="Payment Account"><?php echo e($showdata->mobile_acc); ?></td>
                                        <td data-toggle="tooltip" title="Transaction ID"><?php echo e($showdata->trans_id); ?></td>
                               
                                        <td data-toggle="tooltip" title="SKU">
                                            <?php if($product): ?>
                                            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                           <li><?php echo e($productdata->product_id); ?>,</li>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            <br>
                                        
                                        </td>
                                        <td data-toggle="tooltip" title="Unit Price">
                                            
                                             <?php if($product): ?>
                                            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                           <li><?php echo e($productdata->sp); ?>,</li>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            <!--<?php echo e($showdata->sale_price); ?>-->
                                        
                                        
                                        </td>
                                        <td data-toggle="tooltip" title="Discount Percentage">
                                                <?php if($product): ?>
                                            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                           <li><?php echo e(floor($productdata->dp/$productdata->sp*100)); ?>%,</li>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            <!--<?php echo e(floor($showdata->discount_price/$showdata->sale_price*100)); ?>%-->
                                            
                                            
                                            </td>
                                        <td data-toggle="tooltip" title="Discount Amount">
                                         <?php if($product): ?>
                                            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                           <li><?php echo e($productdata->dp); ?>,</li>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        
                                        </td>
                                        <td data-toggle="tooltip" title="Discounted Price">
                                        
                                         <?php if($product): ?>
                                            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                           <li><?php echo e($productdata->cp); ?>,</li>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </td>
                                        <td data-toggle="tooltip" title="Quantity">
                                            <?php if($product): ?>
                                            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                           <li><?php echo e($productdata->quantity); ?>,</li>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            <br>
                                        
                                        </td>
                                        <td><?php echo e($showdata->delivery_charge); ?></td>
                                        <td><?php echo e($showdata->discount); ?></td>
                                        <td><?php echo e($showdata->sub_total); ?></td>
                                        <td><?php echo e($showdata->grand_total); ?></td>
                                        <td><?php echo e($showdata->note); ?></td>
                                        <td><?php echo e($showdata->reject_note); ?></td>
                                        <td>
                                            <?php if($showdata->status == '0'): ?>
                                            <a class="btn btn-warning btn-sm">pending</a>
                                            <?php elseif($showdata->status == '1'): ?>
                                              <a class="btn btn-info btn-sm">process</a>
                                            
                                            <?php elseif($showdata->status == '5'): ?>
                                              <a class="btn btn-primary btn-sm">shipping</a>
                                            <?php elseif($showdata->status == '2'): ?>
                                              <a class="btn btn-secondary btn-sm">on the way</a>
                                            <?php elseif($showdata->status == '3'): ?>
                                              <a class="btn btn-success btn-sm">complete</a>
                                            <?php elseif($showdata->status == '6'): ?>
                                              <a class="btn btn-info btn-sm">Refound</a>
                                            <?php elseif($showdata->status == '4'): ?>
                                              <a class="btn btn-danger btn-sm">Reject</a>
                                             <?php endif; ?>
                                        </td>
                                        <?php if(Auth('admin')->user()->type == '1'): ?>
                                        <td>
                                            
                                             <?php if($showdata->status == '0'): ?>
                                             
                                            <a class="btn btn-outline-info btn-sm" onclick="loadModel('<?php echo e($showdata->invoice_id); ?>')" data-toggle="modal" data-target="#myModal" >Process</a>
                                            <a class="btn btn-outline-warning btn-sm" onclick="protoShipping('<?php echo e($showdata->invoice_id); ?>')">Shipping</a>
                                            <a class="btn btn-outline-primary btn-sm" onclick="proToontheOrder('<?php echo e($showdata->invoice_id); ?>')">On the Way</a>
                                            <a class="btn btn-outline-success btn-sm" onclick="rejecttorefundOrder('<?php echo e($showdata->invoice_id); ?>')">Refound</a>
                                            <a class="btn btn-outline-success btn-sm" onclick="ontheTosuccOrder('<?php echo e($showdata->invoice_id); ?>')">Complete</a>
                                            <a class="btn btn-outline-danger btn-sm" onclick="loadModels('<?php echo e($showdata->invoice_id); ?>')" data-toggle="modal" data-target="#myModal">Reject</a>
                                            <?php elseif($showdata->status == '1'): ?>

                                            <a class="btn btn-outline-warning btn-sm" onclick="protoShipping('<?php echo e($showdata->invoice_id); ?>')">Shipping</a>
                                            <a class="btn btn-outline-primary btn-sm" onclick="proToontheOrder('<?php echo e($showdata->invoice_id); ?>')">On the Way</a>
                                            <a class="btn btn-outline-success btn-sm" onclick="rejecttorefundOrder('<?php echo e($showdata->invoice_id); ?>')">Refound</a>
                                            <a class="btn btn-outline-success btn-sm" onclick="ontheTosuccOrder('<?php echo e($showdata->invoice_id); ?>')">Complete</a>
                                            <a class="btn btn-outline-danger btn-sm" onclick="loadModels('<?php echo e($showdata->invoice_id); ?>')" data-toggle="modal" data-target="#myModal">Reject</a>
                                            
                                            <?php elseif($showdata->status == '5'): ?>
                                            <a class="btn btn-outline-primary btn-sm" onclick="proToontheOrder('<?php echo e($showdata->invoice_id); ?>')">On the Way</a>
                                            <a class="btn btn-outline-success btn-sm" onclick="rejecttorefundOrder('<?php echo e($showdata->invoice_id); ?>')">Refound</a>
                                            <a class="btn btn-outline-success btn-sm" onclick="ontheTosuccOrder('<?php echo e($showdata->invoice_id); ?>')">Complete</a>
                                            <a class="btn btn-outline-danger btn-sm" onclick="loadModels('<?php echo e($showdata->invoice_id); ?>')" data-toggle="modal" data-target="#myModal">Reject</a>
                                            <?php elseif($showdata->status == '2'): ?>

                                            <a class="btn btn-outline-success btn-sm" onclick="rejecttorefundOrder('<?php echo e($showdata->invoice_id); ?>')">Refound</a>
                                            <a class="btn btn-outline-success btn-sm" onclick="ontheTosuccOrder('<?php echo e($showdata->invoice_id); ?>')">Complete</a>
                                            <a class="btn btn-outline-danger btn-sm" onclick="loadModels('<?php echo e($showdata->invoice_id); ?>')" data-toggle="modal" data-target="#myModal">Reject</a>
                                            <?php elseif($showdata->status == '3'): ?>
                                                  <a class="btn btn-outline-success btn-sm" onclick="rejecttorefundOrder('<?php echo e($showdata->invoice_id); ?>')">Refound</a>
                                            <a class="btn btn-outline-danger btn-sm" onclick="loadModels('<?php echo e($showdata->invoice_id); ?>')" data-toggle="modal" data-target="#myModal">Reject</a>
                                            <?php elseif($showdata->status == '6'): ?>
                                              <a class="btn btn-info btn-sm">Refound</a>
                                            <?php elseif($showdata->status == '4'): ?>
                                              <a class="btn btn-danger btn-sm">Reject</a>
                                             <?php endif; ?>
                                            <a href="<?php echo e(url('invoice-paper')); ?>/<?php echo e($showdata->session_id); ?>" class="btn btn-outline-warning btn-sm" target="_blank">View</a>
                                        </td>
                                        <?php else: ?>
                                        <td>
                                            <a href="<?php echo e(url('invoice-paper')); ?>/<?php echo e($showdata->session_id); ?>" class="btn btn-outline-warning btn-sm" target="_blank">View</a>
                                        </td>
                                        <?php endif; ?>
                                        
                                    </tr>
                                    
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                         <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>


                <!-- state end-->

            </div>
        </div>

<?php echo $__env->make('Admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script type="text/javascript">

function loadModel(id)
        {
          $(".modal-body").load("<?php echo e(URL::to('processorder_note')); ?>"+'/'+id);
        }
        
        
        
function loadModels(id)
        {
          $(".modal-body").load("<?php echo e(URL::to('rejectorder_note')); ?>"+'/'+id);
        }
        
function penToProOrder(id)
{
    let note = $("#note").val();
   if(confirm('are you sure?'))
    $.ajax({

            headers:{ 'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>" },
            url:'<?php echo e(url("penToProOrder")); ?>',
            type:'POST',
            data:{id:id,note:note},
            success:function(data)
            {
                $("#tr-"+id).hide();
                $("#sms").html('<span class="alert alert-success">Order Sent to Proccessign</span>');
            }
        })  

    
}
function protoShipping(id)
{
    if(confirm('are you sure?'))

    $.ajax({

            headers:{ 'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>" },
            url:'<?php echo e(url("protoShipping")); ?>',
            type:'POST',
            data:{id:id},
            success:function(data)
            {
                $("#tr-"+id).hide();
                $("#sms").html('<span class="alert alert-success">Order Sent to Shipping</span>');
            }
        })  

    
}
  
function proToontheOrder(id)
{
   if(confirm('are you sure?'))
   
    $.ajax({

            headers:{ 'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>" },
            url:'<?php echo e(url("proToontheOrder")); ?>',
            type:'POST',
            data:{id:id},
            success:function(data)
            {
                $("#tr-"+id).hide();
                $("#sms").html('<span class="alert alert-success">Order Sent By Rider</span>');
            }
        })  

    
}
  
function ontheTosuccOrder(id)
{
   if(confirm('are you sure?'))
   
    $.ajax({

            headers:{ 'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>" },
            url:'<?php echo e(url("ontheTosuccOrder")); ?>',
            type:'POST',
            data:{id:id},
            success:function(data)
            {
                $("#tr-"+id).hide();
                $("#sms").html('<span class="alert alert-success">Order Delivery Success</span>');
            }
        })  

    
}
  
function penTorejectOrder(id)
{
     let note=$("#note").val();
    if(confirm('are you sure?'))
   
    $.ajax({

            headers:{ 'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>" },
            url:'<?php echo e(url("penTorejectOrder")); ?>',
            type:'POST',
            data:{id:id,note:note},
            success:function(data)
            {
                $("#tr-"+id).hide();
                $("#sms").html('<span class="alert alert-danger">Order Reject</span>');
            }
        })  

    
}
  
  
function rejecttorefundOrder(id)
{
    if(confirm('are you sure?'))
   
    $.ajax({

            headers:{ 'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>" },
            url:'<?php echo e(url("rejecttorefundOrder")); ?>',
            type:'POST',
            data:{id:id},
            success:function(data)
            {
                $("#tr-"+id).hide();
                $("#sms").html('<span class="alert alert-danger">Order Refound</span>');
            }
        })  

    
}
  
</script><?php /**PATH D:\xampp\htdocs\office\bdeshishop\resources\views/Admin/Order_system/pending.blade.php ENDPATH**/ ?>