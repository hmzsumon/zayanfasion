<div class="list-group status">
	<a href="#" class="list-group-item list-group-item-action active bg-dark border-0">
		My All Invoice
	</a>
	<div>
		<?php if(isset($data)): ?>
		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $showdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<a href="<?php echo e(url('/viewinvoice/'.$showdata->session_id)); ?>" class="list-group-item list-group-item-action">Invoice NO: <br>#<?php echo e($showdata->invoice_id); ?> 

			<?php if($showdata->status == 0): ?>
			<span class="float-right">Pending</span></a>
			<?php elseif($showdata->status==1): ?>
			<span class="float-right">Processing</span></a>
			<?php elseif($showdata->status==5): ?>
			<span class="float-right">Shipping</span></a>
			<?php elseif($showdata->status==2): ?>
			<span class="float-right">On the way</span></a>
			<?php elseif($showdata->status==3): ?>
			<span class="float-right">Complete</span></a>
			<?php elseif($showdata->status==6): ?>
			<span class="float-right">Refound</span></a>
			<?php elseif($showdata->status==4): ?>
			<span class="float-right">Reject</span></a>
			<?php else: ?>
			<span class="float-right">Failed</span></a>
			<?php endif; ?>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
		</div>
	</div>



	<style scoped="" type="text/css">

		.status span{
			background: #f1f1f1;
			font-size: 14px;
			font-weight: normal;
			padding: 1px 10px;
			border-radius: 30px;
		}

	</style><?php /**PATH D:\xampp\htdocs\office\zayanfashion\resources\views/User/Guest/user-invoice.blade.php ENDPATH**/ ?>