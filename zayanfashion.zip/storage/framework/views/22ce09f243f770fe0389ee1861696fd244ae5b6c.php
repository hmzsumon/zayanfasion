
<?php if(isset($view)): ?>
<?php $__currentLoopData = $view; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $viewdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<div class="col-md-12 pt-2 pb-2 border-bottom">
	<div class="row">
		<div class="col-md-3 col-3">
			<a href=""><img src="<?php echo e(asset('public/productImage')); ?>/<?php echo e($viewdata->image); ?>" class="img-fluid"></a>
		</div>

		<div class="col-md-9 col-9">
			<strong class="text-dark"><?php echo e(substr($viewdata->product_name, 0, 30)); ?>... <span><?php echo e($viewdata->size ?? ''); ?> - <?php echo e($viewdata->color ?? ''); ?></span> </strong>
			<a onclick="delete_product('<?php echo e($viewdata->id); ?>')"><i class="fa fa-trash-o text-dark float-end" uk-tooltip="title: Remove; pos:bottom"></i></a><br>
			<span>৳ <?php echo e($viewdata->current_price); ?> X <?php echo e($viewdata->quantity); ?></span><br>
		
		</div>
	</div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\office\zayanfashion\resources\views/User/viewCart.blade.php ENDPATH**/ ?>