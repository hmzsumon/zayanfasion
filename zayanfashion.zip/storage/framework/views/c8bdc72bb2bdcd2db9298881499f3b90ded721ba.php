<div class="sidemenu p-0 bg-white mt-2">
	<ul class="uk-nav-parent-icon" uk-nav duration='800'>

		<?php
		$item = DB::table('product_item')->orderBy('sl','ASC')->get();
		$category = DB::table('product_category')->get();
		?>

		<?php if(isset($item)): ?>
		<?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php 
		$item_name=str_replace(" ","-",$i->item_name)
		?>

		<li class="uk-parent">
			<a href="<?php echo e(url('item')); ?>/<?php echo e($item_name); ?>/<?php echo e($i->id); ?>"><img src="<?php echo e(asset('public/itemImage')); ?>/<?php echo e($i->image); ?>" class="img-fluid">&nbsp;&nbsp;<?php echo e($i->item_name); ?></a>
			<ul class="uk-nav-sub" hidden>
				<?php if(isset($category)): ?>
				<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($cat->item_id == $i->id): ?>
				<?php 
				$category_name=str_replace(" ","-",$cat->category_name)
				?>
				<li><a href="<?php echo e(url('category')); ?>/<?php echo e($category_name); ?>/<?php echo e($cat->id); ?>"><?php echo e($cat->category_name); ?></a></li>
				<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>
			</ul>
		</li>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>


		<!--<li><a href="<?php echo e(url('hugesaving')); ?>"><img src="<?php echo e(asset('public/fontdev/')); ?>/img/i1.webp" class="img-fluid">&nbsp;&nbsp;Huge Saving</a></li>-->
		<!--<li><a href="<?php echo e(url('ordersavemore')); ?>"><img src="<?php echo e(asset('public/fontdev/')); ?>/img/i2.webp" class="img-fluid">&nbsp;&nbsp;Order more save more</a></li>-->
		<!--<li><a href="<?php echo e(url('dicountoffer')); ?>"><img src="<?php echo e(asset('public/fontdev/')); ?>/img/i3.webp" class="img-fluid">&nbsp;&nbsp;Special Discount </a></li>-->
		<!--<li><a href="<?php echo e(url('buyget')); ?>"><img src="<?php echo e(asset('public/fontdev/')); ?>/img/i4.webp" class="img-fluid">&nbsp;&nbsp;Buy 1 get 1 offers</a></li>-->
		<!--<li><a href="<?php echo e(url('specialservices')); ?>"><img src="<?php echo e(asset('public/fontdev/')); ?>/img/i10.webp" class="img-fluid">&nbsp;&nbsp;Our special discount  offers</a></li>-->

	</ul>
</div>
<?php /**PATH /home/lifenatural/public_html/bdeshishop/resources/views/User/layouts/sidmenu.blade.php ENDPATH**/ ?>