											
<?php
$total =0;
?>
<?php if(isset($view)): ?>
<?php $__currentLoopData = $view; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $viewdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
$total +=$viewdata->current_price*$viewdata->quantity;
?>
<tr class="text-center">

	<td><?php echo e($viewdata->product_name); ?> <br> - <span><?php echo e($viewdata->size ?? ''); ?> - <?php echo e($viewdata->color ?? ''); ?></span>
		<input type="checkbox" name="shipping_id[]" id="shipping_id" value="<?php echo e($viewdata->shipping_id); ?>" checked=""  disabled="">
	</td>
	<td><?php echo e($viewdata->quantity); ?></td>
	<td><?php echo e($viewdata->current_price); ?></td>
	<td><?php echo e($viewdata->current_price*$viewdata->quantity); ?></td>
	<td><a><span uk-icon="icon: trash; ratio: 0.8" class="text-danger" onclick="delete_product('<?php echo e($viewdata->id); ?>')"></span></a></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<tr class="text-center">
	<td></td>
	<td colspan="3">SubTotal</td>
	<td>
		<input type="hidden" name="subamount" id="subamount" value="<?php echo e($total); ?>" required="">
		Tk.<?php echo e($total); ?>.00
	</td>
	<td></td>
</tr>

<tr class="text-center">
	<th></th>
	<td colspan="3">Delivery Charge</td>
	<td>
		<input type="hidden" name="deliverycharge" id="deliverycharge" value="0">
		Tk.<span id="ddcharge">0</span>.00
	</td>
	<td></td>
</tr>	

<tr class="text-center">
	<th></th>
	<td colspan="3">Discount</td>
	<td>
		<input type="hidden" name="discount" id="discount" value="0">
		<input type="hidden" name="super_code" id="super_code">
		Tk.<span id="promo_price">0</span>.00
	</td>
	<td></td>
</tr>	


<tr class="text-center">
	<td></td>
	<th colspan="3">Grand Total</th>
	<th>
		<input type="hidden" name="totalamount" id="totalamount" value="<?php echo e($total); ?>" required="">
		Tk.<span id="gtotal"><?php echo e($total); ?></span>.00

	</th>
	<td></td>
</tr><?php /**PATH D:\xampp\htdocs\office\zayanfashion\resources\views/User/placeordershow.blade.php ENDPATH**/ ?>