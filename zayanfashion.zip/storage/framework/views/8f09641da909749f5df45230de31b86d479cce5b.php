<meta property="og:url" content="<?php echo e(Request::url()); ?>" />
<meta property="og:type" content="Article">
<meta property="og:title" content="<?php echo e($viewproduct->product_name); ?>">
<meta property="og:description" content="<?php echo e($viewproduct->product_name); ?>">
<meta property="og:image" content="<?php echo e(url('/public/productImage')); ?>/<?php echo e($viewproduct->image); ?>" />


<?php $__env->startSection('body'); ?>


<?php
$setting = DB::table('settings')->first();
?>

<style>
    .minus, .plus{
        width:20px;
        height:20px;
        background:#f2f2f2;
        border-radius:4px;
        padding:8px 5px 8px 5px;
        border:1px solid #ddd;
        display: inline-block;
        vertical-align: middle;
        text-align: center;
        height: 42px;
        width: 42px;
    }

    input{
        height:42px;
        width: 100px;
        text-align: center;
        font-size: 26px;
        border:1px solid #ddd;
        border-radius:4px;
        display: inline-block;
        vertical-align: middle; 
    }

    .select_color{
        padding: 6px;
        border: 1px solid #c4c4c4;
        text-align: center;
        cursor: pointer;
        font-weight: 800;
    }

    .selected_color{
        padding: 6px;
        border: 2px solid red !important;
        text-align: center;
        ursor: pointer;
        font-weight: 800;
    }

    .select_size{
        padding: 6px;
        border: 1px solid #c4c4c4;
        text-align: center;
        cursor: pointer;
        font-weight: 800;
    }

    .selected_size{
        padding: 6px;
        border: 2px solid red !important;
        text-align: center;
        ursor: pointer;
        font-weight: 800;
    }

</style>


<div class="col-md-12">
    <div class="container">
        <div class="row">

            
            <!----------End Sidebar-------->

            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 pb-5">
                <div class="col-md-12 mt-3 p-3 bg-white breadcumbs">
                    <li><a href="<?php echo e(url('/')); ?>"><i class="bi bi-house-fill"></i>&nbsp;&nbsp;Home</a></li>
                    <li><i class="bi bi-chevron-right"></i></li>
                    <li><?php echo e($viewproduct->product_name); ?></li>
                </div>


                <div class="col-md-12 mt-4 single bg-white rounded pb-4 p-3 p-lg-0">
                    <div class="row">
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 p-4">

                            <div class="simpleLens-gallery-container" id="demo-1">
                                <div class="simpleLens-container border" style="width: 100%;">
                                    <div class="simpleLens-big-image-container p-2">
                                        <a class="simpleLens-lens-image" data-lens-image="<?php echo e(asset('public/productImage')); ?>/<?php echo e($viewproduct->image); ?>">
                                            <img src="<?php echo e(asset('public/productImage')); ?>/<?php echo e($viewproduct->image); ?>" class="simpleLens-big-image product-image-zoom">
                                        </a>
                                        
                                    </div>
                                </div>

                                <div class="product-thumb-gallery">
                                    <?php $__currentLoopData = $product_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="product-thumb-gallery-item">
                                        <!-- <img src="<?php echo e(asset('public/productImage')); ?>/<?php echo e($viewproduct->image); ?>" alt=""> -->
                                        <img src="<?php echo e(asset('/public/productImage')); ?>/<?php echo e($img->image); ?>" alt="">
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>



                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                            <br>
                            <strong><?php echo e($viewproduct->product_name); ?></strong><br>
                            <span><b>SKU:</b> <?php echo e($viewproduct->product_id); ?></span><br>
                            <?php if($viewproduct->stock_status == 1): ?>
                            <span class="bg-success text-light rounded" style="padding: 2px 10px; font-size: 13px;">Stock Available</span>
                            <?php else: ?>
                            <span class="bg-danger text-light rounded" style="padding: 2px 10px; font-size: 13px;">Stock Out</span>
                            <?php endif; ?>
                            <br><br>

                            <label>৳ <?php echo e(number_format($viewproduct->current_price, 2, '.', ',')); ?></label>

                            <?php if($viewproduct->discount_price > 0): ?>
                            <del>৳ <?php echo e(number_format($viewproduct->sale_price, 2, '.', ',')); ?></del>
                            <?php endif; ?>
                            <br>
                                
                            <?php if(count($product_color)>0): ?>
                            <div class="color_select mt-3 mb-3">
                                <div class="row" style="padding-right: 40px;">
                                    <div class="col-md-12">
                                        <p style="margin: 0"><b>Color : </b></p>
                                        <div class="row mt-2">
                                            <?php $__currentLoopData = $product_color; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-2">
                                                <div class="select_color" data-id="<?php echo e($color->id); ?>"><?php echo e($color->color); ?></div>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <input  type="hidden" name="color" id="customer_selected_color" style="text-align: left;">
                                        </div>
                                    </div>  
                                </div>   
                            </div>
                            <?php endif; ?>
                            
                            <?php if(count($product_size)>0): ?>
                            <div class="color_select mt-3 mb-3">
                                <div class="row" style="padding-right: 40px;">
                                    <div class="col-md-12">
                                        <p style="margin: 0"><b>Size : </b></p>
                                        <div class="row mt-2">
                                            <?php $__currentLoopData = $product_size; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-2">
                                                <div class="select_size"  data-id="<?php echo e($size->id); ?>" style="padding: 6px;border: 1px solid #c4c4c4;text-align: center;cursor: pointer;"><?php echo e($size->size); ?></div>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <input  type="hidden" name="size" id="customer_selected_size" style="text-align: left;">
                                        </div>
                                    </div>  
                                </div>   
                            </div>
                            <?php endif; ?>

                                <img src="<?php echo e(asset('/public/callForOrderImage')); ?>/<?php echo e($setting->call_for_order_image); ?>" alt="" style="margin-top: 16px;">
                                <br>
                                <h4 style="margin:0;font-weight: bolder;display: inline-block;font-family: 'bootstrap-icons';color: #828282;font-size: 25px;">Call For Order</h4>

                                <p class="mt-2" style="margin: 0;font-size: 19px;font-weight: 600;"><?php echo e($setting->number_1 ?? ''); ?></p>
                                <p style="margin: 0;font-size: 19px;font-weight: 600;"><?php echo e($setting->number_2 ?? ''); ?></p>

                                <h5 style="margin:0;margin-top: 20px;"><b>Delivery Charge: Inside Dhaka - <?php echo e($setting->inside_dhaka ?? ''); ?> Tk. / Outside Dhaka - <?php echo e($setting->outside_dhaka ?? ''); ?> Tk.</b></h5>
                            
                                

                                <div class="quentity mt-5">
                                    <label>Quantity</label><br>
                                    <!-- <input type="number" min="<?php echo e($viewproduct->min_qunt); ?>" name="Quantity-<?php echo e($viewproduct->id); ?>" id="Quantity-<?php echo e($viewproduct->id); ?>" value="<?php echo e($viewproduct->min_qunt); ?>"> -->

                                    <div class="number">
                                        <span class="minus">-</span>

                                        <input type="label" class="quantity" min="<?php echo e($viewproduct->min_qunt); ?>" name="Quantity-<?php echo e($viewproduct->id); ?>" id="Quantity-<?php echo e($viewproduct->id); ?>" value="<?php echo e($viewproduct->min_qunt); ?>"/>
                                        <span class="plus">+</span>

                                    </div>

                                </div>

                                <div class="mt-5">
                                    <div class="col-md-12" style="padding-right: 20px;">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <?php if(Auth('guest')->user()): ?>
                                                <a href="<?php echo e(url('/Checkout')); ?>"><button class="cart w-100" style="background: #1b99bf;"><i class="fa fa-shopping-basket" aria-hidden="true"></i>&nbsp;&nbsp;Buy Now</button></a>
                                                <?php else: ?>
                                                <a href="<?php echo e(url('/user-login')); ?>"><button class="cart w-100" style="background: #1b99bf;"><i class="fa fa-shopping-basket" aria-hidden="true"></i>&nbsp;&nbsp;Buy Now</button></a>
                                                <?php endif; ?>
                                            </div>
                                            <div class="col-md-6">
                                                
                                                <?php if($viewproduct->stock_status == 1): ?>
                                                <button class="cart w-100" onclick="AddCart('<?php echo e($viewproduct->id); ?>')"><i class="fa fa-shopping-basket" aria-hidden="true"></i>&nbsp;&nbsp;Add To Cart</button>
                                                <?php else: ?>
                                                <button class="cart w-100" style="cursor: not-allowed;"><i class="fa fa-shopping-basket" aria-hidden="true"></i>&nbsp;&nbsp;Add To Cart</button>
                                                <?php endif; ?>

                                            </div>
                                            
                                        </div>
                                        
                                        
                                    </div>
                                </div>
                            

                            <div class="mt-4">
                                <span>Share With :</span><br>
                                <div class="addthis_inline_share_toolbox_0v9d"></div>

                            </div>


                        </div>



                    </div>
                </div>
                <!--------------End Product's--------------------->





                <div class="col-md-12 bg-white p-0 p-4 details mt-4">

                    <ul class="nav nav-tabs" id="myTab">
                        <li class="nav-item">
                            <a href="#Description" class="nav-link active" data-bs-toggle="tab">Description</a>
                        </li>
                        <li class="nav-item">
                            <a href="#Review" class="nav-link" data-bs-toggle="tab">Review</a>
                        </li>
                        
                    </ul>

                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="Description">
                            <h4 class="mt-2"><?php echo e($viewproduct->product_name); ?></h4>
                            <p><?php echo $viewproduct->product_details; ?></p>
                        </div>

                        <div class="tab-pane fade" id="Review">
                            <div class="rating_details" style="border-bottom: 1px solid #dedede; padding: 25px;">
                                <div class="row">
                                    
                                    <div class="col-md-6" style="text-align: center;">
                                        <?php if($avg_rating > 0): ?>
                                        <h1 style="margin: 0;"><?php echo e(substr($avg_rating, 0, 3)); ?></h1>
                                        <?php else: ?>
                                        <h1 style="margin: 0;">0</h1>
                                        <?php endif; ?>

                                        <?php if($avg_rating == 5): ?>
                                            <span class="fa fa-star checked" style="color: orange;"></span>
                                            <span class="fa fa-star checked" style="color: orange"></span>
                                            <span class="fa fa-star checked" style="color: orange"></span>
                                            <span class="fa fa-star checked" style="color: orange"></span>
                                            <span class="fa fa-star checked" style="color: orange"></span>
                                        <?php elseif($avg_rating >= 4): ?>
                                            <span class="fa fa-star checked" style="color: orange;"></span>
                                            <span class="fa fa-star checked" style="color: orange"></span>
                                            <span class="fa fa-star checked" style="color: orange"></span>
                                            <span class="fa fa-star checked" style="color: orange"></span>
                                            <span class="fa fa-star"></span>
                                        <?php elseif($avg_rating >= 3): ?>
                                            <span class="fa fa-star checked" style="color: orange;"></span>
                                            <span class="fa fa-star checked" style="color: orange"></span>
                                            <span class="fa fa-star checked" style="color: orange"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                        <?php elseif($avg_rating >= 2): ?>
                                            <span class="fa fa-star checked" style="color: orange;"></span>
                                            <span class="fa fa-star checked" style="color: orange"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                        <?php elseif($avg_rating >= 1): ?>
                                            <span class="fa fa-star checked" style="color: orange;"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                        <?php else: ?>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                        <?php endif; ?>
                                        
                                        <p style="margin: 0;">Average Rating based on <?php echo e($total_rating ?? 0); ?> reviews.</p>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="row">
                                          <div class="side">
                                            <div>5 star</div>
                                          </div>
                                          <div class="middle">
                                            <div class="bar-container">
                                              <div class="bar-5" style="width: <?php echo e($five_star ?? 0); ?>%;"></div>
                                            </div>
                                          </div>
                                          <div class="side right">
                                            <div><?php echo e($five_star ?? 0); ?></div>
                                          </div>
                                          <div class="side">
                                            <div>4 star</div>
                                          </div>
                                          <div class="middle">
                                            <div class="bar-container">
                                              <div class="bar-4" style="width: <?php echo e($four_star ?? 0); ?>%; "></div>
                                            </div>
                                          </div>
                                          <div class="side right">
                                            <div><?php echo e($four_star ?? 0); ?></div>
                                          </div>
                                          <div class="side">
                                            <div>3 star</div>
                                          </div>
                                          <div class="middle">
                                            <div class="bar-container">
                                              <div class="bar-3" style="width: <?php echo e($three_star ?? 0); ?>%;"></div>
                                            </div>
                                          </div>
                                          <div class="side right">
                                            <div><?php echo e($three_star ?? 0); ?></div>
                                          </div>
                                          <div class="side">
                                            <div>2 star</div>
                                          </div>
                                          <div class="middle">
                                            <div class="bar-container">
                                              <div class="bar-2" style="width: <?php echo e($two_star ?? 0); ?>%; "></div>
                                            </div>
                                          </div>
                                          <div class="side right">
                                            <div><?php echo e($two_star ?? 0); ?></div>
                                          </div>
                                          <div class="side">
                                            <div>1 star</div>
                                          </div>
                                          <div class="middle">
                                            <div class="bar-container">
                                              <div class="bar-1" style="width: <?php echo e($one_star ?? 0); ?>%; "></div>
                                            </div>
                                          </div>
                                          <div class="side right">
                                            <div><?php echo e($one_star ?? 0); ?></div>
                                          </div>
                                        </div>
                                    </div>

                                </div>
                            </div>

                            <div class="row">
                                
                                <div class="col-md-6">

                                    <?php if(count($product_ratings)>0): ?>
                                        <?php $__currentLoopData = $product_ratings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php  
                                            $guest = DB::table('guest')->where('id', $product_rating->guest_id)->first();
                                        ?>
                                        <div class="comments" style="padding: 14px;padding: 14px;border: 1px solid #e4e4e4;">

                                            <h4 style="margin:0;color: darkgreen;font-weight: bold;font-size: 17px;"><?php echo e($guest->first_name); ?>

                                            (

                                                <?php if($product_rating->guest_rating == 5): ?>
                                                    <span class="fa fa-star checked" style="color: orange;"></span>
                                                    <span class="fa fa-star checked" style="color: orange"></span>
                                                    <span class="fa fa-star checked" style="color: orange"></span>
                                                    <span class="fa fa-star checked" style="color: orange"></span>
                                                    <span class="fa fa-star checked" style="color: orange"></span>
                                                <?php elseif($product_rating->guest_rating >= 4): ?>
                                                    <span class="fa fa-star checked" style="color: orange;"></span>
                                                    <span class="fa fa-star checked" style="color: orange"></span>
                                                    <span class="fa fa-star checked" style="color: orange"></span>
                                                    <span class="fa fa-star checked" style="color: orange"></span>
                                                    <span class="fa fa-star"></span>
                                                <?php elseif($product_rating->guest_rating >= 3): ?>
                                                    <span class="fa fa-star checked" style="color: orange;"></span>
                                                    <span class="fa fa-star checked" style="color: orange"></span>
                                                    <span class="fa fa-star checked" style="color: orange"></span>
                                                    <span class="fa fa-star"></span>
                                                    <span class="fa fa-star"></span>
                                                <?php elseif($product_rating->guest_rating >= 2): ?>
                                                    <span class="fa fa-star checked" style="color: orange;"></span>
                                                    <span class="fa fa-star checked" style="color: orange"></span>
                                                    <span class="fa fa-star"></span>
                                                    <span class="fa fa-star"></span>
                                                    <span class="fa fa-star"></span>
                                                <?php elseif($product_rating->guest_rating >= 1): ?>
                                                    <span class="fa fa-star checked" style="color: orange;"></span>
                                                    <span class="fa fa-star"></span>
                                                    <span class="fa fa-star"></span>
                                                    <span class="fa fa-star"></span>
                                                    <span class="fa fa-star"></span>
                                                <?php else: ?>
                                                    <span class="fa fa-star"></span>
                                                    <span class="fa fa-star"></span>
                                                    <span class="fa fa-star"></span>
                                                    <span class="fa fa-star"></span>
                                                    <span class="fa fa-star"></span>
                                                <?php endif; ?>

                                            ) </h4>

                                            <p style="margin:0;font-size: 14px;color: #6e6e6e;"><?php echo $product_rating->comment; ?> </p>

                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <p style="text-align: center; margin-top: 2rem;font-size: 18px;font-weight: 700;">No Rating Yet</p>
                                    <?php endif; ?>

                                </div>
                                <div class="col-md-6">
                                    <div style="border-left: 1px solid #f4eaea; padding: 10px;">
                                        <h4 class="mt-2"><strong>Write Your Review</strong></h4>
                                        <?php if(Session::has('feedback_submited')): ?>
                                            <p class="alert <?php echo e(Session::get('alert-class', 'alert-success')); ?>"><?php echo e(Session::get('feedback_submited')); ?></p>
                                        <?php endif; ?>

                                        <?php if($errors->any()): ?>
                                            <div class="alert alert-danger">
                                              <ul>
                                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                              </ul>
                                            </div>
                                            <?php endif; ?>

                                        <?php if(Auth('guest')->user()): ?>
                                        <form action="<?php echo e(route('submit-feedback')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="product_id" value="<?php echo e($viewproduct->product_id); ?>">
                                            <input type="hidden" name="guest_id" value="<?php echo e(Auth('guest')->id()); ?>">
                                            <div class="mb-3">
                                                <label for="exampleFormControlInput1" class="form-label">Rating</label>
                                                <select name="guest_rating" id="" class="form-control" style="color: #ff9f06;font-weight: bolder;" required="">
                                                    <option value="5">★★★★★</option>
                                                    <option value="4">★★★★</option>
                                                    <option value="3">★★★</option>
                                                    <option value="2">★★</option>
                                                    <option value="1">★</option>
                                                </select>
                                            </div>
                                            <div class="mb-3">
                                                <label for="exampleFormControlInput1" class="form-label">Comment</label>
                                                <textarea name="comment" class="form-control summernote" rows="3" required=""></textarea>
                                            </div>
                                            <button type="submit" class="btn btn-warning text-light">Submit</button>
                                        </form>
                                        <?php else: ?>

                                        <a href="<?php echo e(url('user-login')); ?>" class="text-dark"><button type="submit" class="btn btn-warning text-light">Login</button></a>

                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>

                </div>




                <div class="col-md-12 mt-5 cathead">
                    <strong>Related Products</strong>
                    <div class="row">

                        <?php if(isset($related_product)): ?>
                        <?php $__currentLoopData = $related_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $productname = str_replace(['%', '/', ' '], '-', $r->product_name);
                        ?>



                        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-4 col-6 mt-4">
                            <div class="bg-white product p-3">
                                <center>
                                    <a href="<?php echo e(url('product')); ?>/<?php echo e($productname); ?>/<?php echo e($r->product_id); ?>"><img src="<?php echo e(asset('public/productImage')); ?>/<?php echo e($r->image); ?>" alt=""></a>
                                    <div class="text-dark fw-bold productname mt-3 text-center">
                                        
                                        <div class="productname_height">
                                            <?php echo e(substr($r->product_name, 0, 50)); ?>

                                        </div>

                                        <span>৳ <?php echo e($r->current_price); ?></span></div>
                                    <div class="mt-2"><button class="btn btn-success btn-sm" onclick="AddCart('<?php echo e($r->id); ?>')">Add To Cart</button></div>
                                </center>
                            </div>
                        </div>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>






                    </div>
                </div>





            </div>


        </div>
    </div>
</div>









<?php $__env->stopSection(); ?>
<?php echo $__env->make('User.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\office\zayanfashion\resources\views/User/single-product.blade.php ENDPATH**/ ?>