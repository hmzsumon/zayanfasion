
<?php $__env->startSection('body'); ?>

<div class="col-md-12">
	<div class="container">
		<div class="row">

			<div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col-3 d-none d-lg-block"> 
				<?php echo $__env->make('User.layouts.sidmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			</div><!----------End Sidebar-------->

			<div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 col-12 pb-5">

				<div class="col-md-12 detailspage mt-4 p-4">
					<strong>How To Buy Products</strong><br><br>
					<span>
						<?php echo $data->description; ?>

					</span>
				</div>




			</div>

			
		</div>
	</div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('User.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lifenatural/public_html/zayanfashion/resources/views/User/howtobuys.blade.php ENDPATH**/ ?>