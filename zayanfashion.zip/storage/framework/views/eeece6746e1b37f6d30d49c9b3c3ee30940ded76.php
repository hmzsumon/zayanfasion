<?php echo $__env->make('Admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<br>
<br>
<br>






<div class="main-content" style="overflow: hidden;">

            <!--page title start-->
            <div class="page-title" style="float: left;">
                <h4 class="mb-0">
                    <small>Page Category</small>
                </h4>
              
            </div>
            
         
            <!--page title end-->


            <div class="container" style="overflow-x: scroll; max-height:726px">

                <!-- state start-->
                <div class="row">
                    <div class=" col-sm-12">
                        <div class="mb-4">
                   
                                    <span id="sms"></span>
                            <div class="card-body">
                                <table id="example" class="display nowrap" style="width:100%;text-align:center;">
                                    <thead>
                                    <tr>
                                       <th>SL</th>
                                        <th>Title</th>
                                        <th>Slug</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tfoot>
                                    <tr>
                                       <th>SL</th>
                                        <th>Title</th>
                                        <th>Slug</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php
                                        $sl=1;
                                        ?>
                                        <?php if(isset($pages)): ?>
                                        <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $showdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      
                                      <tr id="tr-<?php echo e($showdata->invoice_id); ?>">
                                        <td data-toggle="tooltip" title="SL"><?php echo e($sl++); ?></td>
                                        <td data-toggle="tooltip" title="Order ID"><?php echo e($showdata->title); ?></td>
                                        <td data-toggle="tooltip" title="Order ID"><?php echo e($showdata->slug); ?></td>

                                        <td>
                                            <?php if($showdata->status == '0'): ?>
                                            <a class="btn btn-warning btn-sm">Inactive</a>
                                            <?php elseif($showdata->status == '1'): ?>
                                              <a class="btn btn-info btn-sm">Active</a>
                                             <?php endif; ?>
                                        </td>
                                        <td>
                                          <div class="row">
                                             <a href="<?php echo e(route('page.edit', $showdata->id)); ?>" class="btn btn-outline-warning btn-sm mr-2" target="_blank" style="float: left;">Edit</a>

                                            <form action="<?php echo e(route('page.destroy', $showdata->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button class="btn btn-outline-warning btn-sm" style="float: left;">Delete</button>
                                            </form> 
                                          </div>
                                            

                                        </td>
                                    </tr>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                         <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>


                <!-- state end-->

            </div>
        </div>

<?php echo $__env->make('Admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\xampp\htdocs\office\zayanfashion\resources\views/Admin/page/index.blade.php ENDPATH**/ ?>