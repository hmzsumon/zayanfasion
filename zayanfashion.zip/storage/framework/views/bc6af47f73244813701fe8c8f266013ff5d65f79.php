<?php echo $__env->make('Admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<br>
<br>
<br>


<div class="modal fade" id="myModal" role="dialog" >
  <div class="modal-dialog modal-lg" >
  
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Edit Data</h4>
      </div>
      <div class="modal-body" >
        <p>
                

        </p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
    
  </div>
</div>



<div class="main-content" style="overflow: hidden;">
            <!--page title start-->
            <div class="page-title">
                <h4 class="mb-0">View Admin
                    <small></small>
                </h4>
                <ol class="breadcrumb mb-0 pl-0 pt-1 pb-0">
                    <li class="breadcrumb-item"><a href="#" class="default-color">Home</a></li>
                    <li class="breadcrumb-item active">View Admin</li>
                </ol>
            </div>
            <!--page title end-->


            <div class="container" style="overflow-x: scroll;">

                <!-- state start-->
                <div class="row">
                    <div class=" col-sm-12">
                        <div class="mb-4">
                   
                            <div class="card-body">
                                <table id="example" class="display nowrap" style="width:100%">
                                    <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Address</th>
                                        <th>Image</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tfoot>
                                    <tr>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Address</th>
                                        <th>Image</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php if(Auth('admin')->user()->id == '1'): ?>
                                    	<?php if(isset($data)): ?>
                                    	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $showdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr id="tr-<?php echo e($showdata->id); ?>">
                                        <td><?php echo e($showdata->name); ?></td>
                                        <td><?php echo e($showdata->email); ?></td>
                                        <td><?php echo e($showdata->phone); ?></td>
                                        <td><?php echo e($showdata->address); ?></td>
                                        <td><img src="<?php echo e(asset('public/AdminImage')); ?>/<?php echo e($showdata->image); ?>" style="width: 50px;height: 50px"></td>
                                        <td>
                                        	<?php if($showdata->status == '1'): ?>
                                        	<span style="color: green;font-family: monospace;">Active</span>
                                        	<?php else: ?>
                                        	 	<span style="color: orange;font-family: monospace;">Inactive</span>
                                        	<?php endif; ?>

                                        </td>
                                        <td>
                                        	<?php if($showdata->status == '1'): ?>
                                        	<a href="#" class="btn btn-danger" onclick="inactivestatus('<?php echo e($showdata->id); ?>')">Inactive</a>
                                        	<?php else: ?>
                                        	<a href="#" class="btn btn-success"  onclick="activestatus('<?php echo e($showdata->id); ?>')">Active</a>
                                        	<?php endif; ?>

                                        	<a href="<?php echo e(url('/editadminModal')); ?>/<?php echo e($showdata->id); ?>"
                                class="btn btn-primary btn-mini" >Update</a>
                                        	<a href="#" class="btn btn-danger" onclick="deleteaccount('<?php echo e($showdata->id); ?>')">Delete</a>
                                        </td>
                                       
                                    	</tr>
                                    	
                                    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    	<?php endif; ?>

                                        <?php else: ?>

                                        <?php if(isset($data)): ?>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $showdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($showdata->id != '1'): ?>
                                        <tr id="tr-<?php echo e($showdata->id); ?>">
                                        <td><?php echo e($showdata->name); ?></td>
                                        <td><?php echo e($showdata->email); ?></td>
                                        <td><?php echo e($showdata->phone); ?></td>
                                        <td><?php echo e($showdata->address); ?></td>
                                        <td><img src="<?php echo e(asset('public/AdminImage')); ?>/<?php echo e($showdata->image); ?>" style="width: 50px;height: 50px"></td>
                                        <td>
                                            <?php if($showdata->status == '1'): ?>
                                            <span style="color: green;font-family: monospace;">Active</span>
                                            <?php else: ?>
                                                <span style="color: orange;font-family: monospace;">Inactive</span>
                                            <?php endif; ?>

                                        </td>
                                        <td>
                                            <?php if($showdata->status == '1'): ?>
                                            <a href="#" class="btn btn-danger" onclick="inactivestatus('<?php echo e($showdata->id); ?>')">Inactive</a>
                                            <?php else: ?>
                                            <a href="#" class="btn btn-success"  onclick="activestatus('<?php echo e($showdata->id); ?>')">Active</a>
                                            <?php endif; ?>

                                            <a href="<?php echo e(url('/editadminModal')); ?>/<?php echo e($showdata->id); ?>"
                                class="btn btn-primary btn-mini" >Update</a>
                                            <a href="#" class="btn btn-danger" onclick="deleteaccount('<?php echo e($showdata->id); ?>')">Delete</a>
                                        </td>
                                       
                                        </tr>
                                        
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>


                <!-- state end-->

            </div>
        </div>

<?php echo $__env->make('Admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script type="text/javascript">
	function loadModel(id)
{
  $(".modal-body").load("<?php echo e(URL::to('editadminModal')); ?>"+'/'+id);
}

function inactivestatus(id)
{

      $.ajax({
        headers: { 'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>" },
        url: '<?php echo e(url("inactive-status-admin")); ?>',
        type: 'POST',
        data: {id:id},
        success: function(data){
		location.reload(); 
        }
      });
      

}

function activestatus(id)
{

      $.ajax({
        headers: { 'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>" },
        url: '<?php echo e(url("active-status-admin")); ?>',
        type: 'POST',
        data: {id:id},
        success: function(data){
		location.reload(); 
        }
      });
      

}
function deleteaccount(id)
{

if(confirm('Are you sure?'))
{
      $.ajax({
        headers: { 'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>" },
        url: '<?php echo e(url("delete-account-admin")); ?>',
        type: 'POST',
        data: {id:id},
        success: function(data){
		$("#tr-"+id).hide(); 
        }
      }); 
}
   
      

}
</script><?php /**PATH D:\xampp\htdocs\office\zayanfashion\resources\views/Admin/Create_admin/view.blade.php ENDPATH**/ ?>