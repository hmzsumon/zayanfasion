		<?php
		$total =0;
		?>
		<?php if(isset($view)): ?>
		<?php $__currentLoopData = $view; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $viewdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

		<?php
		$total +=$viewdata->current_price*$viewdata->quantity;
		?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>
		<?php echo e($total); ?><?php /**PATH /home/lifenatural/public_html/bdeshishop/resources/views/User/total_price.blade.php ENDPATH**/ ?>