<?php echo $__env->make('Admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<br>
<br>
<br>






<div class="main-content" style="overflow: hidden;">
  <!--page title start-->
  <div class="page-title" style="float: left;">
    <h4 class="mb-0">View Product
      <small></small>
    </h4>

  </div>
  <div class="page-title" style="float: right; ">
    <a href="<?php echo e(route('product-add.create')); ?>" class="btn btn-outline-success">Add product</a> 
    <a href="<?php echo e(url('/Admin-dashboard')); ?>" class="btn btn-danger">X</a>
  </div>
  <!--page title end-->


  <div class="container" style="overflow-x: scroll;">

    <div class="row">
      <div class=" col-sm-12">
        <div class="mb-4">

      

                <div class="card-body p-0 mt-4">
                  <table id="example" class="display nowrap" style="width:100%">
                    <thead>
                      <tr>

                        <th>SL</th>
                        <th>Product ID</th>
                        <th>Item Name</th>
                        <th>Category Name</th>

                        <th>Brand Name</th>

                        <th>Product Name</th>
                        <th>Measurement Type</th>
                        <!--<th>Size Type</th>-->
                        <!--<th>Color Type</th>-->
                        <th>Purchase Price</th>
                        <th>Sale Price</th>
                        <th>Discount Price</th>
                        <th>Current Price</th>
                        <th>Minimum Quantity</th>
                        <th>Type</th>
                        <th>Offer</th>
                        <th>Image</th>
                        <th>Action</th>
                      </tr>
                    </thead>

                    <tbody >
                     <?php
                     $sl=1;
                     ?>
                     <?php if(isset($data)): ?>
                     <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $showdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr id="tr-<?php echo e($showdata->id); ?>">

                      <td><?php echo e($sl++); ?></td>
                      <td><?php echo e($showdata->product_id); ?></td>
                      <td><?php echo e($showdata->item_name); ?></td>
                      <td><?php echo e($showdata->category_name); ?></td>

                      <td><?php echo e($showdata->company_name); ?></td>

                      <td><?php echo e($showdata->product_name); ?></td>
                      <td><?php echo e($showdata->measurement_type ?? ''); ?></td>

                      <td><?php echo e($showdata->purchase_price); ?></td>
                      <td><?php echo e($showdata->sale_price); ?></td>
                      <td><?php echo e($showdata->discount_price); ?></td>
                      <td><?php echo e($showdata->current_price); ?></td>
                      <td><?php echo e($showdata->min_qunt); ?></td>
                      <td><?php echo e($showdata->shipping_name); ?></td>
                      <td>
                        <?php if($showdata->offer_id  == 1): ?>
                        Huge Savings
                        <?php elseif($showdata->offer_id  == 2): ?>
                        Order More Save more 
                        <?php elseif($showdata->offer_id  == 3): ?>
                        Special Discount Offers
                        <?php elseif($showdata->offer_id  == 4): ?>
                        Buy one get 1 free 
                        <?php elseif($showdata->offer_id  == 5): ?>
                        Special Services
                        <?php endif; ?>
                      </td>
                      <td>

                        <?php if($showdata->image): ?>
                        <div uk-lightbox="animation: fade">
                         <a href="<?php echo e(asset('/public/productImage')); ?>/<?php echo e($showdata->image); ?>"> <img src="<?php echo e(asset('/public/productImage')); ?>/<?php echo e($showdata->image); ?>" style="width: 50px;height: 50px"></a>
                       </div>        

                       <?php else: ?>
                       <div uk-lightbox="animation: fade">
                         <a href="<?php echo e(asset('/public')); ?>/noimage.png"> <img src="<?php echo e(asset('/public')); ?>/noimage.png" style="width: 50px;height: 50px"></a>
                       </div>
                       <?php endif; ?>


                     </td>
                     <td>

                       <?php if($showdata->status == '0'): ?>
                       <a href="<?php echo e(url('productstatusactive',$showdata->id)); ?>" class="btn btn-outline-danger">Inactive</a>

                       <?php else: ?>
                       <a href="<?php echo e(url('productstatusinactive',$showdata->id)); ?>" class="btn btn-outline-success">Active</a>
                       <?php endif; ?>

                       <a href="<?php echo e(route('product-add.edit',$showdata->id)); ?>" class="btn btn-outline-primary">Edit</a>

                       <a href="<?php echo e(url('/deleteadminproduct/'.$showdata->id)); ?>" class="btn btn-outline-danger" onclick="return confirm('Are you sure?')">Delete</a>

                     </td>
                   </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   <?php endif; ?>
                 </tbody>


               </table>


             </div>
           </div>
         </div>
       </div>


     </div>












   </div>

   <?php echo $__env->make('Admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


 </script>
<?php /**PATH /home/lifenatural/public_html/bdeshishop/resources/views/Admin/product/index.blade.php ENDPATH**/ ?>