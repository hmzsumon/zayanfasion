

<?php $__env->startSection('body'); ?>


<?php
$date = substr($viewcart[0]->created_at,0,10);
$setting = DB::table('settings')->first();
?>

<div class="container">
<div class="col-md-12">

		<div class="row">


			<div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 col-12 mt-4">
				<?php echo $__env->make('User.Guest.user-invoice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			</div>


			<div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 col-12 mt-4">
				<div class="col-md-12 p-4 invoice">

					<strong>Invoice NO: #<?php echo e($viewcart[0]->invoice_id); ?> </strong>

					<div class="col-md-12 col-12 p-4 mt-4 border">
						<div class="row">
							<div class="col-md-4" style="font-size: 13px;">
								<img src="<?php echo e(asset('/public/siteImage')); ?>/<?php echo e($setting->logo); ?>" class="img-fluid" style="max-height: 45px;"><br>
								<div class="mt-2">
									Invoice No: #<?php echo e($viewcart[0]->invoice_id); ?><br>
									Order Date: <?php echo e($date); ?><br>
									Payment Status: <?php echo e($viewcart[0]->payment_type); ?><br>
								</div><br>
							</div>


							<div class="col-md-8 text-left text-sm-end" >
							
							</div>

						</div>


						<center><h6 class="p-2 font-weight-bold text-uppercase">Sales Invoice</h6></center><br>
						<div class="row" style="font-size: 13px;">
							<div class="col-md-7">
								<h6 class="font-weight-bold text-uppercase">Billing</h6>
								Name: <?php echo e($viewcart[0]->guestfirstname); ?>&nbsp;<?php echo e($viewcart[0]->guestlastname); ?><br>
								<!-- Vessel: <?php echo e($viewcart[0]->guestvessel_name); ?><br>
								Rank: <?php echo e($viewcart[0]->guestrank); ?><br> -->
								Phone: <?php echo e($viewcart[0]->guestphone); ?>

							</div>


							<div class="col-md-5">
								<h6 class="font-weight-bold text-uppercase">Shipping</h6>
								Name: <?php echo e($viewcart[0]->first_name); ?>&nbsp;<?php echo e($viewcart[0]->last_name); ?><br>
								<!-- Vessel: <?php echo e($viewcart[0]->vessel_name); ?><br>
								Rank: <?php echo e($viewcart[0]->rank); ?><br> -->
								Phone: <?php echo e($viewcart[0]->phone); ?><br>
								Address: <?php echo e($viewcart[0]->address); ?>

							</div>
						</div>


						<br>
						<div class="table-responsive">

							<table class="table table-bordered">
								<thead class="bg-dark text-light">
									<th>SL</th>
									<th>Product</th>
									<th>SKU</th>
									<th>Price</th>
									<th>QTY</th>
									<th>Amount</th>
								</thead>


								<tbody>

									<?php
									$sl=1;

									$payment =  $balance->payment;
									?>  

									<?php if($payment>0): ?>
									$payments=$payment;
									<?php else: ?>

									<?php endif; ?>

									<?php if(isset($viewcart)): ?>
									<?php $__currentLoopData = $viewcart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


									<tr>
										<td><?php echo e($sl++); ?></td>
										<td style="text-align: left;">
		                                    <p><?php echo e($cart->product_name); ?> - <span><?php echo e($cart->size ?? ''); ?> - <?php echo e($cart->color ?? ''); ?></span>
		                                    </p>
		                                </td>
										<td><?php echo e($cart->sku); ?></td>
										<td ><?php echo e($cart->current_price); ?> Tk</td>
										<td><?php echo e($cart->quantity); ?></td>
										<td><?php echo e($cart->current_price * $cart->quantity); ?> Tk</td>
									</tr>

									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>


								</tbody>

								<tfoot>
									<tr>
										<th colspan="3"></th>
										<th colspan="2">Sub Total</th>
										<th><?php echo e($viewcart[0]->sub_total); ?> Tk</th>
									</tr>

									<tr>
										<th colspan="3"></th>
										<th colspan="2">Delivery Charge(+)</th>
										<th><?php echo e($viewcart[0]->delivery_charge); ?> Tk</th>
									</tr>

									<?php if($viewcart[0]->coupon_id !='' && $viewcart[0]->discount>0): ?>
									<tr>
										<th colspan="3"></th>
										<th colspan="2">Discount(-)</th>
										<th><?php echo e($viewcart[0]->discount); ?> Tk</th>
									</tr>
									<?php endif; ?>



									<tr>
										<th colspan="3"></th>
										<th colspan="2">Grand Total</th>
										<th><?php echo e($viewcart[0]->grand_total); ?> Tk</th>
									</tr>

							

								</tfoot>

							</table>
							
						</div>


						<br>
						<center><span style="font-weight:600; font-size:13px;">[ Note: This is computer generate copy. No signature is required ]</span></center>
					</div>


				</div>
			</div>




		</div>
	</div>
</div><!------------End invoice-------------->




<style type="text/css" scoped="">

	thead{
		font-size: 14px;
	}

	tbody{
		font-size: 14px;
	}

	tfoot{
		font-size: 14px;
		white-space: nowrap;
	}
</style>





<?php $__env->stopSection(); ?>




<?php echo $__env->make('User.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\office\zayanfashion\resources\views/User/Guest/viewinvoice.blade.php ENDPATH**/ ?>