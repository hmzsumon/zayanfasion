<?php echo $__env->make('Admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php  

    $setting = DB::table('settings')->first();
    
?>
<body class="app header-fixed left-sidebar-fixed right-sidebar-fixed right-sidebar-overlay right-sidebar-hidden">

    <!--===========header start===========-->
    
    <!--===========header end===========-->

    <!--===========app body start===========-->

    <style type="text/css">
        .card-shadow{
            font-weight: bold;
            font-size: 20px!important;
        }
    </style>



    <div class="app-body">

        <main class="main-content" style="font-size: 20px;">
            <!--page title start-->
            <div class="page-title">
                <div class="container p-0 mb-2">
                    <div class="row">
                        <div class="col-8">
                            <h3 class="font-weight-bold"> Welcome To <span class="text-danger"><?php echo e($setting->title); ?></span>
                            </h3>
                     
                        </div>

                    </div>
                </div>
            </div>

            <!--page title end-->


            <div class="container">

                <!--state widget start-->
                <div class="row">

                    <?php

                    $totaladmin = DB::table('createadmin')->get();
                    $totalproduct = DB::table('product_productinfo')->count();
                    $activeproduct = DB::table('product_productinfo')->where('status',1)->count();
                    $inactiveproduct = DB::table('product_productinfo')->where('status',0)->count();



                    ?>

                    <div class="col-xl-3 col-sm-6 mb-4">
                        <div class="card card-shadow bg-success">
                            <div class="card-body ">
                                <i class="icon-people text-light f30"></i>
                                <a href="<?php echo e(url('view-admin')); ?>" style="text-decoration:none; color: #f1f1f1;"><h6 class="mb-0 mt-3 text-light font-weight-bold">Total Admin</h6>
                                    <p class="f12 mb-0"><?php echo e(count($totaladmin)); ?>  Users</p></a>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="row">


                        <div class="col-xl-3 col-sm-6 mb-4">
                            <div class="card card-shadow bg-warning">
                                <div class="card-body ">
                                    <i class="icon-people text-light f30"></i>
                                    <a href="<?php echo e(url('GuestList')); ?>" style="text-decoration:none;"><h6 class="mb-0 mt-3 text-light font-weight-bold">Register Users</h6>
                                        <p class="f12 mb-0 text-light"><?php echo e($user); ?>  Users</p></a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-sm-6 mb-4">
                                <div class="card card-shadow bg-success">
                                    <div class="card-body ">
                                        <i class="icon-people text-light f30"></i>
                                        <a href="<?php echo e(url('GuestListactive')); ?>" style="text-decoration:none;color:green;"> <h6 class="mb-0 mt-3 text-light font-weight-bold">Active Users</h6>
                                            <p class="f12 mb-0 text-light"><?php echo e($acuser); ?>  Users</p></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-sm-6 mb-4">
                                    <div class="card card-shadow bg-danger">
                                        <div class="card-body ">
                                            <i class="icon-people text-light f30"></i>
                                            <a href="<?php echo e(url('GuestListinactive')); ?>" style="text-decoration:none;"> <h6 class="mb-0 mt-3 text-light font-weight-bold">Inactive Users</h6>
                                                <p class="f12 mb-0 text-light"><?php echo e($inuser); ?>  Users</p></a>
                                            </div>
                                        </div>
                                    </div>







                                    <div class="col-xl-3 col-sm-6 mb-4">
                                        <div class="card card-shadow bg-dark">
                                            <div class="card-body ">
                                                <i class="icon-chart text-light f30"></i>
                                                <a href="" style="text-decoration:none;"> <h6 class="mb-0 mt-3 text-light font-weight-bold">Total Product's</h6>
                                                    <p class="f12 mb-0 text-light"><?php echo e($totalproduct); ?>  Products</p></a>
                                                </div>
                                            </div>
                                        </div>


                                        <div class="col-xl-3 col-sm-6 mb-4">
                                            <div class="card card-shadow bg-info">
                                                <div class="card-body ">
                                                    <i class="icon-chart text-light f30"></i>
                                                    <a href="" style="text-decoration:none;"> <h6 class="mb-0 mt-3 text-light font-weight-bold">Active Products</h6>
                                                        <p class="f12 mb-0 text-light"><?php echo e($activeproduct); ?>  Products</p></a>
                                                    </div>
                                                </div>
                                            </div>



                                            <div class="col-xl-3 col-sm-6 mb-4">
                                                <div class="card card-shadow bg-primary">
                                                    <div class="card-body ">
                                                        <i class="icon-chart text-light f30"></i>
                                                        <a href="" style="text-decoration:none;"> <h6 class="mb-0 mt-3 text-light font-weight-bold">Inactive Products</h6>
                                                            <p class="f12 mb-0 text-light"><?php echo e($inactiveproduct); ?>  Products</p></a>
                                                        </div>
                                                    </div>
                                                </div>



                         












                                                        </div>

                                                    </div>

                                                </main>

                                            </div>
                                            <?php echo e(Auth('admin')->user()->type); ?>



                                            <?php echo $__env->make('Admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                        </body>

                                        </html>
                                        <!-- Data table -->

<!-- https://datatables.net/extensions/buttons/examples/initialisation/export.html --><?php /**PATH D:\xampp\htdocs\office\zayanfashion\resources\views/Admin/index.blade.php ENDPATH**/ ?>