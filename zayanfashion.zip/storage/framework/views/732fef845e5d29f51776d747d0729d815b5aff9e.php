
<?php $__env->startSection('body'); ?>





<div class="col-md-12">
	<div class="container padd">
		<div class="row">


			<div class="col-xl-3 col-lg-3 col-md-4 col-sm-5 col-12 mt-4">
				<?php echo $__env->make('User.Guest.user-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			</div>


			<div class="col-xl-9 col-lg-9 col-md-8 col-sm-7 col-12 mt-4">
				<div class="col-md-12 p-4 userdashboard">

					<strong><i class="fa fa-map-marker" aria-hidden="true"></i>&nbsp;&nbsp;Personal Information</strong><br><br>
					<table class="table table-bordered">
						<tr>
							<th>Name:</th>
							<td><?php echo e(Auth('guest')->user()->first_name); ?></td>
						</tr>

				

						<tr>
							<th>Phone:</th>
							<td><?php echo e(Auth('guest')->user()->phone); ?></td>
						</tr>

						<tr>
							<th>Email:</th>
							<td><?php echo e(Auth('guest')->user()->email); ?></td>
						</tr>

						<!-- <tr>
							<th>Vessel:</th>
							<td><?php echo e(Auth('guest')->user()->vessel_name); ?></td>
						</tr>
						
						
							<tr>
							<th>Rank:</th>
							<td><?php echo e(Auth('guest')->user()->rank); ?></td>
						</tr> -->
					</table>



					<div class="row">

						<div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12 mt-4">
							<div class="dash p-3 bg-info">
								<label><?php echo e(count($data)); ?></label><br>
								<a href="">Total Order</a>
							</div>
						</div>


						<div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12 mt-4">
							<div class="dash p-3 bg-danger">
								<label><?php echo e(count($pending)); ?></label><br>
								<a href="">Pending Order</a>
							</div>
						</div>



						<div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12 mt-4">
							<div class="dash p-3 bg-warning">
								<label><?php echo e(count($processing)); ?></label><br>
								<a href="">Processing Order</a>
							</div>
						</div>

						<div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12 mt-4">
							<div class="dash p-3 bg-success">
								<label><?php echo e(count($delivered)); ?></label><br>
								<a href="">Delivered Order</a>
							</div>
						</div>

						

					</div>


					
				</div>
			</div>



		</div>
	</div>
</div><!------------End Dashboard-------------->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('User.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lifenatural/public_html/zayanfashion/resources/views/User/Guest/dashboard.blade.php ENDPATH**/ ?>