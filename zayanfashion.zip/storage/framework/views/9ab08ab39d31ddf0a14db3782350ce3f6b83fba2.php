
<?php $__env->startSection('body'); ?>



<div class="col-md-12">
	<div class="container padd">
		<div class="row">


			<div class="col-xl-3 col-lg-3 col-md-4 col-sm-12 col-12 mt-4">
				<?php echo $__env->make('User.Guest.user-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			</div>


			<div class="col-xl-9 col-lg-9 col-md-8 col-sm-12 col-12 mt-4">
				<div class="col-md-12 p-4 userdashboard">

					<strong>All Orders</strong><br><br>

					<div class="table-responsive">
						<table id="example" class="table table-bordered table-striped">
							<thead>
								<tr>
									<th>Order</th>
									<th>Order Date</th>
									<th>Ammount</th>
									<th>Payment</th>
									<th>Status</th>
								</tr>
							</thead>


							<tbody>

								<?php if($data): ?>
								<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $showdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

								<tr>
									<td><a href="<?php echo e(url('/viewinvoice/'.$showdata->session_id)); ?>" class="text-dark font-weight-bold">#<?php echo e($showdata->invoice_id); ?></a></td>
									<td><?php echo e($showdata->date); ?></td>
									<td>&#2547; <?php echo e($showdata->grand_total); ?></td>
									<td><?php echo e($showdata->payment_type); ?></td>
									<?php if($showdata->status == 0): ?>
									<td><span class="orderstatus bg-info">Pending</span></td>
									<?php elseif($showdata->status==1): ?>
									<td><span class="orderstatus bg-info">Processing</span></td>
									<?php elseif($showdata->status==5): ?>
									<td><span class="orderstatus bg-dark">Shipping</span></td>
									<?php elseif($showdata->status==2): ?>
									<td><span class="orderstatus bg-warning">On the way</span></td>
									<?php elseif($showdata->status==3): ?>
									<td><span class="orderstatus bg-success">Complete</span></td>
									<?php elseif($showdata->status==6): ?>
									<td><span class="orderstatus bg-warning">Refound</span></td>
									<?php elseif($showdata->status==4): ?>
									<td><span class="orderstatus bg-danger">Reject</span></td>

									<?php else: ?>
									<td><span class="orderstatus bg-danger">Failed</span></td>
									<?php endif; ?>
								</tr>

								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>

							</tbody>


						</table>
					</div>



				</div>
			</div>







		</div>
	</div>
</div><!------------End Dashboard-------------->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('User.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\office\zayanfashion\resources\views/User/Guest/allorder.blade.php ENDPATH**/ ?>