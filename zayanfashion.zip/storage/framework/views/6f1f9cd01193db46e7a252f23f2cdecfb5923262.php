<?php echo $__env->make('Admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<div class="main-content">
  <div class="container">

    <br>
    <br>
    <br>
    <br>
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
    <?php endif; ?>
    <div class="row">
      <div class="col-md-12">

        <div class="card card-shadow mb-4">
          <div class="card-header">
            <div class="card-title" style="float: left;">
              Edit Product
            </div> 
            <div class="card-title" style="float: right;">
              <a href="<?php echo e(route('product-add.index')); ?>" class="btn btn-warning">View</a>
              <a href="<?php echo e(url('/Admin-dashboard')); ?>" class="btn btn-danger">X</a>
            </div>
          </div>
          <div class="card-body">
            <form method="post" action="<?php echo e(route('product-add.update',$data->id)); ?>" name="basic_validate"  novalidate="novalidate" enctype="multipart/form-data">
              <?php echo method_field('PATCH'); ?>
              <?php echo csrf_field(); ?>
              <div class="row">
                <div class="col-md-6">

                  <div class="control-group mb-3">
                    <label class="control-label">Item Name</label>
                    <div class="controls">
                      <select name="item_id" onchange="GetCategory();"  id="item_id" class="form-control searchjs">
                        <option value="<?php echo e($data->item_id); ?>"><?php echo e($data->item_name); ?></option>
                        <?php if(count($iteminfo)): ?>
                        <?php $__currentLoopData = $iteminfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->id != $data->item_id): ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->item_name); ?></option>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                      </select>
                    </div>
                  </div>


                  <div class="control-group mb-3">
                    <label class="control-label">Category Name</label>
                    <div class="controls">
                      <select name="category_id" id="category_id" onchange="getsubcat();" class="form-control searchjs1">
                       <option value="<?php echo e($data->category_id); ?>"><?php echo e($data->category_name); ?></option>
                     </select>
                   </div>
                 </div>


                 <div class="control-group mb-3">
                  <label class="control-label">Brand Name</label>
                  <div class="controls">
                    <select name="brand_id" id="brand_id" class="form-control searchjs3">
                      <option value="<?php echo e($data->brand_id); ?>"><?php echo e($data->company_name); ?></option>
                      <?php if(isset($company) && count($company)): ?>
                      <?php $__currentLoopData = $company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $com): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($com->id != $data->brand_id): ?>
                      <option value="<?php echo e($com->id); ?>"><?php echo e($com->company_name); ?></option>
                      <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>
                    </select>
                  </div>
                </div>

                <?php if(Auth('admin')->user()->id == '1' || Auth('admin')->user()->id == '26'): ?>
                <div class="control-group mb-3">
                  <label class="control-label">Product Code</label>
                  <div class="controls">
                    <input type="text" name="product_id" id="product_id" class="form-control" placeholder="Productcode"   value="<?php echo e($data->product_id); ?>" />
                  </div>
                </div>
                <?php else: ?>
                <input type="hidden" name="product_id" id="product_id" class="form-control" placeholder="Productcode"   value="<?php echo e($data->product_id); ?>" />
                <?php endif; ?>

                <div class="control-group mb-3">
                  <label class="control-label">Product Name:</label>
                  <div class="controls">
                    <input type="text" name="product_name" id="product_name" class="form-control" placeholder="Product Name (English)"   value="<?php echo e($data->product_name); ?>" />
                  </div>
                </div>


                <div class="control-group mb-3">
                  <label class="control-label">Min. Quntity</label>
                  <div class="controls">
                    <input type="number" min="1" name="min_qunt" id="min_qunt" class="form-control" placeholder="ex:2"   value="<?php echo e($data->min_qunt); ?>"/>
                  </div>
                </div>

                <div class="control-group mb-3">
                  <label class="control-label">Measurement Type:</label>
                  <div class="controls">
                    <select class="form-control searchjs4" name="measurement_type" id="measurement_type">
                      <?php if($measurementinfo): ?>
                      <?php $__currentLoopData = $measurementinfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $measurement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($measurement->id); ?>" <?php if ($data->measurement_type == $measurement->id) { echo "selected"; } ?>><?php echo e($measurement->measurement_type); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>
                    </select>
                  </div>
                </div>





                <div class="control-group mb-3">
                  <label class="control-label">Purchase Price:</label>
                  <div class="controls">
                    <input type="number" name="purchase_price" id="purchase_price" class="form-control" placeholder="Purchase Price"  value="<?php echo e($data->purchase_price); ?>"/>
                  </div>
                </div>



                <div class="control-group mb-3">
                  <label class="control-label">Sale Price</label>
                  <div class="controls">
                    <input type="number" name="sale_price" id="sale_price" class="form-control" class="form-control" placeholder="Sale Price"  value="<?php echo e($data->sale_price); ?>"/>
                  </div>
                </div> 
                <div class="control-group mb-3">
                  <label class="control-label">Discount Amount</label>
                  <div class="controls">
                    <input type="number" name="discount_price" id="discount_price" class="form-control" class="form-control" placeholder="Discount Amount"  value="<?php echo e($data->discount_price); ?>"/>
                  </div>
                </div>



                <div class="control-group mb-3">
                  <label class="control-label">Discount percentage</label>
                  <div class="controls">
                    <input type="number" name="discount_per" id="discount_per" class="form-control" class="form-control" placeholder="Discount percentage"  value="<?php echo e($data->discount_per); ?>"/>
                  </div>
                </div>

                <div class="control-group mb-3">
                  <label class="control-label">Current Price</label>
                  <div class="controls">
                    <input type="number" name="current_price" id="current_price" class="form-control" class="form-control" placeholder="Cuurent Price"  value="<?php echo e($data->current_price); ?>"/>
                  </div>
                </div>



              </div>   

              <div class="col-md-6">




                <div class="control-group mb-3">

                  <label class="control-label">Short Description</label>

                  <div class="controls">
                    <textarea name="product_us" id="product_us" class="form-control" style="resize: none;"><?php echo e($data->product_us); ?></textarea>
                  </div>
                </div>  

                <div class="control-group mb-3">

                  <label class="control-label">Product Details </label>

                  <div class="controls">
                    <textarea name="product_details" id="product_details" class="form-control" style="resize: none;"><?php echo e($data->product_details); ?></textarea>
                  </div>
                </div>        



                <div class="control-group mb-3">

                  <label class="control-label">Stock Available/Out</label>

                  <div class="controls">
                    <select name="stock_status" id="stock_status" class="form-control" >
                      <?php if($data->stock_status == '1'): ?>
                      <option value="1">Stock Available</option>
                      <option value="0">Stock Out</option>
                      <?php else: ?>
                      <option value="0">Stock Out</option>
                      <option value="1">Stock Available</option>
                      <?php endif; ?>

                    </select>
                  </div>
                </div>


                <div class="control-group mb-3">

                  <label class="control-label">Shipping Class</label>

                  <div class="controls">
                    <select name="shipping_id" id="shipping_id" class="form-control searchjs5" >

                      <?php if($shipping): ?>
                      <?php $__currentLoopData = $shipping; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($ship->id == $data->shipping_id): ?>
                      <option value="<?php echo e($ship->id); ?>"><?php echo e($ship->shipping_name); ?></option>
                      <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?> 

                      <?php if($shipping): ?>
                      <?php $__currentLoopData = $shipping; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($ship->id != $data->shipping_id): ?>
                      <option value="<?php echo e($ship->id); ?>"><?php echo e($ship->shipping_name); ?></option>
                      <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>

                    </select>
                  </div>
                </div>

                <div class="control-group mb-3">

                  <label class="control-label">Product Image:</label>

                  <div class="controls">

                        <?php
                            $path= base_path().'/public/productImage/'.$data->image;
                        ?>
                        <?php if($data->image): ?>
                        <img src="<?php echo e(asset('/public/productImage')); ?>/<?php echo e($data->image); ?>" alt="">
                        <?php endif; ?>


                    <input type="file" name="image[]" id="image" multiple>

                        <div class="row">
                          <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img src="<?php echo e(asset('/public/productImage')); ?>/<?php echo e($img->image); ?>" alt="" style="width: 9rem;">
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                  </div>
                </div>




                <div class="control-group mb-3">

                  <label class="control-label text-danger"><b>Offer Select</b></label>

                  <div class="controls">

                    <select name="offer_id" id="offer_id" class="form-control">

                     <option value="<?php echo e($data->offer_id); ?>"></option>

                     <option value="1" <?php if ($data->offer_id == 1) { echo "selected"; } ?>>Huge Savings</option>
                     <option value="2" <?php if ($data->offer_id == 2) { echo "selected"; } ?>>Order More Save more</option>
                     <option value="3" <?php if ($data->offer_id == 3) { echo "selected"; } ?>>Discount Offer</option>
                     <option value="4" <?php if ($data->offer_id == 4) { echo "selected"; } ?>>Buy one get 1 free</option>
                     <option value="5" <?php if ($data->offer_id == 5) { echo "selected"; } ?>>Special Services</option>

                   </select>

                 </div>

               </div>




             </div>
           </div>
           <br>
           <div align="center">
             <input type="submit" name="submit" value="update" class="btn btn-info">
           </div>
         </form>
       </div>
     </div>




   </div>
 </div>
</div>
</div>
<?php echo $__env->make('Admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!--<script src="<?php echo e(URL::to('/')); ?>/public/editor3/ckeditor.js"></script> -->

<link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.css" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.js"></script>

<script>
  $('#product_us').summernote(); 
  $('#product_details').summernote(); 
  $('#condition').summernote(); 
</script>
<script type="text/javascript">

//CKEDITOR.replace('editor1');

function GetCategory() {
  var item_id=$('#item_id').val();
  if (item_id!=0) {
    $.ajax({
      headers: { 'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>" },
      url: '<?php echo e(url("CreateProductGetCategory")); ?>',
      type: 'POST',
      data: {id: item_id},
      success: function(data){
        $('#category_id').html(data);
          //GetBrand(); 
        }
      });
  } 
  else {
    $('#category_id').html('<option value="0">Select A Category</option>');
  }
}

function getsubcat() {
  var category_id=$('#category_id').val();
  if (category_id!=0) {
    $.ajax({
      headers: { 'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>" },
      url: '<?php echo e(url("CreateProductGetsubCategory")); ?>',
      type: 'POST',
      data: {id: category_id},
      success: function(data){
        $('#subcategory_id').html(data);
          //GetBrand(); 
        }
      });
  } 
  else {
    $('#subcategory_id').html('<option value="0">Select A subCategory</option>');
  }
}
</script>

<?php /**PATH D:\xampp\htdocs\office\bdeshishop\resources\views/Admin/product/modal.blade.php ENDPATH**/ ?>